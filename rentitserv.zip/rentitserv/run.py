"""
Entry point for RentIT Flask application.
"""
import os
from app import create_app
from logging_config import get_logger

logger = get_logger(__name__)

# Create Flask app
app = create_app()

if __name__ == '__main__':
    # Development settings
    from config import Config
    
    debug = os.getenv('FLASK_DEBUG', True)
    host = Config.SERVER_HOST
    port = Config.SERVER_PORT
    
    logger.info(f"Starting RentIT application on {host}:{port}")
    logger.info(f"Access the application at {Config.URL_SCHEME}://{Config.SERVER_DOMAIN}")
    
    app.run(
        host=host, 
        port=port,
        debug=debug,
        use_reloader=True
    )
