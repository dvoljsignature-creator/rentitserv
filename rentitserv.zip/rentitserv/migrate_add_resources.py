#!/usr/bin/env python3
"""
Migration script to add new tables for employees, inventory, and kits.
Run this script to update the database schema.

Usage:
    python migrate_add_resources.py
"""
import os
import sys
from datetime import datetime

# Add the parent directory to the path so we can import app
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app
from app.models import db, Employee, Inventory, Kit

def migrate():
    """Run migration to create new tables."""
    print("\n" + "="*60)
    print("🗄️  RentIT Database Migration - Resources Management")
    print("="*60)
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    try:
        print("⏳ Initializing application...")
        app = create_app()
        print("✓ Application initialized\n")
        
        print("⏳ Creating database tables...")
        with app.app_context():
            db.create_all()
            
            # Verify tables
            inspector = db.inspect(db.engine)
            tables = inspector.get_table_names()
            
            print("✓ Database tables created successfully!\n")
            
            print("📊 New tables added:")
            print("  ✓ employees")
            print("  ✓ inventory")
            print("  ✓ kits")
            
            print("\n📋 Table Details:")
            print("-" * 60)
            
            for table_name in ['employees', 'inventory', 'kits']:
                if table_name in tables:
                    columns = inspector.get_columns(table_name)
                    print(f"\n📦 {table_name.upper()}")
                    print(f"   Columns: {len(columns)}")
                    for col in columns[:5]:  # Show first 5 columns
                        print(f"      • {col['name']}: {str(col['type'])}")
                    if len(columns) > 5:
                        print(f"      ... and {len(columns) - 5} more")
            
            print("\n" + "-" * 60)
            print("\n✅ Migration completed successfully!\n")
            
            print("📝 Next steps:")
            print("  1. Run: python run.py")
            print("  2. Open: http://localhost:8192")
            print("  3. Navigate to: Сотрудники / Инвентарь / Комплекты")
            print("\n" + "="*60 + "\n")
        
        return 0
        
    except Exception as e:
        print(f"\n❌ Migration failed: {e}\n")
        import traceback
        traceback.print_exc()
        print("\n" + "="*60 + "\n")
        return 1

if __name__ == '__main__':
    exit_code = migrate()
    sys.exit(exit_code)
