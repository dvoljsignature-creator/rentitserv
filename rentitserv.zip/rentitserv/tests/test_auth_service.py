"""
Tests for authentication service.
"""
import pytest
from app.models import db, User
from app.services import AuthService


def test_password_validator():
    """Test password validation."""
    from app.services.auth_service import PasswordValidator
    
    # Valid password
    is_valid, msg = PasswordValidator.validate('SecurePassword123!')
    assert is_valid
    assert msg is None
    
    # Too short
    is_valid, msg = PasswordValidator.validate('Short1!')
    assert not is_valid
    assert 'characters' in msg
    
    # No uppercase
    is_valid, msg = PasswordValidator.validate('securepassword123!')
    assert not is_valid
    
    # No numbers
    is_valid, msg = PasswordValidator.validate('SecurePassword!')
    assert not is_valid
    
    # No special chars
    is_valid, msg = PasswordValidator.validate('SecurePassword123')
    assert not is_valid


def test_email_validator():
    """Test email validation."""
    from app.services.auth_service import EmailValidator
    
    # Valid emails
    assert EmailValidator.validate('user@example.com')
    assert EmailValidator.validate('test.email+tag@domain.co.uk')
    
    # Invalid emails
    assert not EmailValidator.validate('invalid.email')
    assert not EmailValidator.validate('@example.com')
    assert not EmailValidator.validate('user@.com')


def test_user_registration(app_context):
    """Test user registration."""
    success, user = AuthService.register(
        email='newuser@example.com',
        username='newuser',
        password='SecurePassword123!',
        first_name='New',
        last_name='User'
    )
    
    assert success
    assert user.email == 'newuser@example.com'
    assert user.username == 'newuser'
    assert user.check_password('SecurePassword123!')


def test_register_duplicate_email(app_context, test_user):
    """Test registration with duplicate email."""
    success, msg = AuthService.register(
        email=test_user.email,
        username='different',
        password='SecurePassword123!'
    )
    
    assert not success
    assert 'Электронная почта уже зарегистрирована' in msg


def test_register_duplicate_username(app_context, test_user):
    """Test registration with duplicate username."""
    success, msg = AuthService.register(
        email='different@example.com',
        username=test_user.username,
        password='SecurePassword123!'
    )
    
    assert not success
    assert 'Имя пользователя уже занято' in msg


def test_user_login(app_context, test_user):
    """Test user login."""
    success, tokens = AuthService.login('test@example.com', 'TestPassword123!')
    
    assert success
    assert 'access_token' in tokens
    assert 'refresh_token' in tokens
    assert 'token_type' in tokens
    assert tokens['token_type'] == 'Bearer'


def test_login_invalid_password(app_context, test_user):
    """Test login with invalid password."""
    success, msg = AuthService.login('test@example.com', 'WrongPassword')
    
    assert not success
    assert 'Невер' in msg


def test_login_nonexistent_user(app_context):
    """Test login with nonexistent user."""
    success, msg = AuthService.login('nonexistent@example.com', 'SomePassword123!')
    
    assert not success
    assert 'Невер' in msg


def test_verify_token(app_context, test_user):
    """Test token verification."""
    tokens = AuthService.generate_tokens(test_user)
    
    success, payload = AuthService.verify_token(tokens['access_token'])
    
    assert success
    assert payload['user_id'] == test_user.id
    assert payload['email'] == test_user.email


def test_verify_invalid_token(app_context):
    """Test verification of invalid token."""
    success, msg = AuthService.verify_token('invalid.token.string')
    
    assert not success
    assert 'Невер' in msg


def test_refresh_tokens(app_context, test_user):
    """Test token refresh."""
    tokens = AuthService.generate_tokens(test_user)
    
    success, new_tokens = AuthService.refresh_tokens(tokens['refresh_token'])
    
    assert success
    assert 'access_token' in new_tokens
    assert new_tokens['access_token'] != tokens['access_token']


def test_revoke_token(app_context, test_user):
    """Test token revocation."""
    tokens = AuthService.generate_tokens(test_user)
    
    success = AuthService.revoke_token(tokens['refresh_token'])
    assert success
    
    # Try to refresh revoked token
    success, msg = AuthService.refresh_tokens(tokens['refresh_token'])
    assert not success
