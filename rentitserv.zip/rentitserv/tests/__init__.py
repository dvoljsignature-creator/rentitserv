"""
Tests package initialization.
"""
