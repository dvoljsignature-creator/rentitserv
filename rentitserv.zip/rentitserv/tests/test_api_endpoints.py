"""
Tests for API endpoints.
"""
import pytest
import json
from app.models import db, User
from app.services import AuthService


def test_register_endpoint(client):
    """Test user registration endpoint."""
    response = client.post('/api/auth/register', json={
        'email': 'newuser@example.com',
        'username': 'newuser',
        'password': 'SecurePassword123!',
        'first_name': 'New',
        'last_name': 'User'
    })
    
    assert response.status_code == 201
    data = json.loads(response.data)
    assert 'user' in data
    assert data['user']['email'] == 'newuser@example.com'


def test_register_invalid_email(client):
    """Test registration with invalid email."""
    response = client.post('/api/auth/register', json={
        'email': 'invalid-email',
        'username': 'newuser',
        'password': 'SecurePassword123!'
    })
    
    assert response.status_code == 409


def test_register_weak_password(client):
    """Test registration with weak password."""
    response = client.post('/api/auth/register', json={
        'email': 'user@example.com',
        'username': 'newuser',
        'password': 'weak'
    })
    
    assert response.status_code == 409


def test_register_missing_fields(client):
    """Test registration with missing fields."""
    response = client.post('/api/auth/register', json={
        'email': 'user@example.com'
    })
    
    assert response.status_code == 400


def test_login_endpoint(client, test_user):
    """Test login endpoint."""
    response = client.post('/api/auth/login', json={
        'email': 'test@example.com',
        'password': 'TestPassword123!'
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert 'tokens' in data
    assert 'access_token' in data['tokens']


def test_login_invalid_credentials(client, test_user):
    """Test login with invalid credentials."""
    response = client.post('/api/auth/login', json={
        'email': 'test@example.com',
        'password': 'WrongPassword'
    })
    
    assert response.status_code == 401


def test_login_nonexistent_user(client):
    """Test login for nonexistent user."""
    response = client.post('/api/auth/login', json={
        'email': 'nonexistent@example.com',
        'password': 'SomePassword123!'
    })
    
    assert response.status_code == 401


def test_get_profile_endpoint(client, auth_headers):
    """Test get profile endpoint."""
    response = client.get('/api/auth/profile', headers=auth_headers)
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert 'user' in data
    assert data['user']['email'] == 'test@example.com'


def test_get_profile_without_auth(client):
    """Test get profile without authentication."""
    response = client.get('/api/auth/profile')
    
    assert response.status_code == 401


def test_refresh_token_endpoint(client, auth_headers):
    """Test token refresh endpoint."""
    # First get a refresh token
    response = client.post('/api/auth/login', json={
        'email': 'test@example.com',
        'password': 'TestPassword123!'
    })
    
    tokens = json.loads(response.data)['tokens']
    refresh_token = tokens['refresh_token']
    
    # Refresh
    response = client.post('/api/auth/refresh', json={
        'refresh_token': refresh_token
    })
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert 'tokens' in data
    assert 'access_token' in data['tokens']


def test_logout_endpoint(client, auth_headers):
    """Test logout endpoint."""
    # First get a refresh token
    response = client.post('/api/auth/login', json={
        'email': 'test@example.com',
        'password': 'TestPassword123!'
    })
    
    tokens = json.loads(response.data)['tokens']
    refresh_token = tokens['refresh_token']
    
    # Logout
    response = client.post('/api/auth/logout',
        headers=auth_headers,
        json={'refresh_token': refresh_token}
    )
    
    assert response.status_code == 200


def test_forgot_password_endpoint(client):
    """Test forgot password endpoint."""
    response = client.post('/api/password/forgot', json={
        'email': 'test@example.com'
    })
    
    assert response.status_code == 200


def test_health_endpoint(client):
    """Test health check endpoint."""
    response = client.get('/health')
    
    assert response.status_code == 200
    data = json.loads(response.data)
    assert data['status'] == 'ok'
