"""
Test configuration and fixtures.
"""
import pytest
import os
from app import create_app
from app.models import db, User, TOTPSettings, RefreshToken
from config import TestingConfig


@pytest.fixture
def app():
    """Create and configure test app."""
    app = create_app(config=TestingConfig)
    
    with app.app_context():
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    """Test client."""
    return app.test_client()


@pytest.fixture
def app_context(app):
    """Application context."""
    with app.app_context():
        yield


@pytest.fixture
def test_user(app_context):
    """Create test user."""
    user = User(
        email='test@example.com',
        username='testuser',
        first_name='Test',
        last_name='User',
        is_verified=True,
        is_active=True
    )
    user.set_password('TestPassword123!')
    db.session.add(user)
    db.session.commit()
    return user


@pytest.fixture
def auth_headers(client, test_user):
    """Get auth headers with valid token."""
    from app.services import AuthService
    
    tokens = AuthService.generate_tokens(test_user)
    return {'Authorization': f"Bearer {tokens['access_token']}"}
