"""
Tests for password reset service.
"""
import pytest
from app.models import db, User
from app.services import PasswordResetService


def test_request_password_reset(app_context, test_user):
    """Test password reset request."""
    success, msg = PasswordResetService.request_password_reset(test_user.email)
    
    assert success
    
    # Check token was set
    user = User.query.get(test_user.id)
    assert user.reset_token is not None
    assert user.reset_token_expires is not None


def test_request_password_reset_nonexistent(app_context):
    """Test password reset request for nonexistent user."""
    success, msg = PasswordResetService.request_password_reset('nonexistent@example.com')
    
    # Should return success for security (don't reveal if email exists)
    assert success


def test_verify_reset_token(app_context, test_user):
    """Test reset token verification."""
    # Create token
    PasswordResetService.request_password_reset(test_user.email)
    
    # Get token
    user = User.query.get(test_user.id)
    token = user.reset_token
    
    # Verify
    success, verified_user = PasswordResetService.verify_reset_token(token)
    
    assert success
    assert verified_user.id == test_user.id


def test_verify_invalid_token(app_context):
    """Test verification of invalid token."""
    success, msg = PasswordResetService.verify_reset_token('invalid_token')
    
    assert not success
    assert 'Невер' in msg


def test_reset_password(app_context, test_user):
    """Test password reset."""
    # Request reset
    PasswordResetService.request_password_reset(test_user.email)
    
    # Get token
    user = User.query.get(test_user.id)
    token = user.reset_token
    
    # Reset password
    new_password = 'NewPassword123!'
    success, msg = PasswordResetService.reset_password(token, new_password)
    
    assert success
    
    # Check password changed
    user = User.query.get(test_user.id)
    assert user.check_password(new_password)
    assert not user.check_password('TestPassword123!')
    assert user.reset_token is None


def test_reset_password_invalid_token(app_context):
    """Test password reset with invalid token."""
    success, msg = PasswordResetService.reset_password('invalid_token', 'NewPassword123!')
    
    assert not success
