"""
Authentication service module.
Handles user registration, login, password management, and JWT tokens.
"""
from datetime import datetime, timedelta
from functools import wraps
import secrets
import re
import jwt
from flask import current_app, request
from flask import url_for
from werkzeug.security import generate_password_hash, check_password_hash
from app.models import db, User, RefreshToken
from logging_config import get_logger

logger = get_logger(__name__)


class PasswordValidator:
    """Validates password strength according to configuration."""
    
    @staticmethod
    def validate(password):
        """
        Validate password strength.
        Returns tuple (is_valid, error_message)
        """
        config = current_app.config
        errors = []
        
        # Check minimum length
        if len(password) < config['PASSWORD_MIN_LENGTH']:
            errors.append(f"Пароль должен быть не менее {config['PASSWORD_MIN_LENGTH']} символов")
        
        # Check for uppercase
        if config['PASSWORD_REQUIRE_UPPERCASE'] and not re.search(r'[A-Z]', password):
            errors.append("Пароль должен содержать хотя бы одну заглавную букву")
        
        # Check for numbers
        if config['PASSWORD_REQUIRE_NUMBERS'] and not re.search(r'\d', password):
            errors.append("Пароль должен содержать хотя бы одну цифру")
        
        # Check for special characters
        if config['PASSWORD_REQUIRE_SPECIAL'] and not re.search(r'[!@#$%^&*()_+\-\=\[\]{};:\'\",.<>?/\\|`~]', password):
            errors.append("Пароль должен содержать хотя бы один специальный символ")
        
        if errors:
            return False, "; ".join(errors)
        
        return True, None


class EmailValidator:
    """Validates email format."""
    
    EMAIL_REGEX = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    
    @staticmethod
    def validate(email):
        """Validate email format."""
        if not re.match(EmailValidator.EMAIL_REGEX, email):
            return False
        return True


class AuthService:
    """Service for authentication operations."""
    
    @staticmethod
    def register(email, username, password, first_name=None, last_name=None):
        """
        Register a new user.
        
        Args:
            email: User email
            username: Username
            password: Password
            first_name: Optional first name
            last_name: Optional last name
            
        Returns:
            tuple (success, user or error_message)
        """
        try:
            # Validate email format
            if not EmailValidator.validate(email):
                logger.warning(f"Invalid email format: {email}")
                return False, "Неверный формат электронной почты"
            
            # Validate password
            is_valid, error_msg = PasswordValidator.validate(password)
            if not is_valid:
                logger.warning(f"Password validation failed: {error_msg}")
                return False, error_msg
            
            # Check if user exists
            existing_user = User.query.filter(
                (User.email == email) | (User.username == username)
            ).first()
            
            if existing_user:
                logger.warning(f"User already exists: {email} or {username}")
                if existing_user.email == email:
                    return False, "Электронная почта уже зарегистрирована"
                return False, "Имя пользователя уже занято"
            
            # Create new user
            user = User(
                email=email,
                username=username,
                first_name=first_name,
                last_name=last_name,
            )
            user.set_password(password)

            # Generate email verification token
            verification_token = secrets.token_urlsafe(24)
            user.verification_token = verification_token
            user.verification_token_expires = datetime.utcnow() + timedelta(hours=24)
            
            db.session.add(user)
            db.session.commit()
            
            logger.info(f"User registered successfully: {email}")
            return True, user
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Registration error: {str(e)}")
            return False, "Регистрация не удалась"
    
    @staticmethod
    def login(email, password):
        """
        Authenticate user and return JWT tokens.
        
        Args:
            email: User email
            password: User password
            
        Returns:
            tuple (success, tokens_dict or error_message)
        """
        try:
            user = User.query.filter_by(email=email).first()
            
            if not user or not user.check_password(password):
                logger.warning(f"Login failed: Invalid credentials for {email}")
                return False, "Неверный адрес электронной почты или пароль"
            
            if not user.is_active:
                logger.warning(f"Login failed: User inactive - {email}")
                return False, "Аккаунт неактивен"
            
            if not user.is_verified:
                logger.warning(f"Login attempt before verification: {email}")
                return False, "Пожалуйста, подтвердите электронную почту"
            
            # Check if TOTP is enabled
            if user.totp_enabled:
                # Determine available TOTP methods for this user.
                methods = []
                if user.totp_settings:
                    # If an app secret exists, app TOTP is available
                    try:
                        if getattr(user.totp_settings, 'secret', None):
                            methods.append('app')
                    except Exception:
                        pass

                    # If settings indicate email or email_totp_secret column exists,
                    # consider email TOTP available as well.
                    try:
                        ttype = getattr(user.totp_settings, 'totp_type', None)
                        if ttype == 'email' or ttype == 'both' or getattr(user.totp_settings, 'email_totp_secret', None) is not None:
                            methods.append('email')
                    except Exception:
                        pass

                # Fallback: if user.totp_type on user object is set
                if not methods and getattr(user, 'totp_type', None):
                    methods.append(user.totp_type)

                # Ensure uniqueness
                methods = list(dict.fromkeys(methods))

                logger.info(f"User has TOTP enabled ({methods}): {email}")

                return True, {"requires_totp": True, "user_id": user.id, "totp_methods": methods}
            
            # Update last login
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            # Generate tokens
            tokens = AuthService.generate_tokens(user)
            
            logger.info(f"User logged in successfully: {email}")
            return True, tokens
            
        except Exception as e:
            logger.error(f"Login error: {str(e)}")
            return False, "Ошибка входа"
    
    @staticmethod
    def generate_tokens(user):
        """
        Generate JWT access and refresh tokens for a user.
        
        Args:
            user: User object
            
        Returns:
            dict with access_token, refresh_token, and expires_in
        """
        try:
            access_token_payload = {
                'user_id': user.id,
                'email': user.email,
                'username': user.username,
                'iat': datetime.utcnow(),
                'exp': datetime.utcnow() + current_app.config['JWT_ACCESS_TOKEN_EXPIRES'],
            }
            
            access_token = jwt.encode(
                access_token_payload,
                current_app.config['JWT_SECRET_KEY'],
                algorithm='HS256'
            )
            
            # Create refresh token
            refresh_token_str = secrets.token_urlsafe(32)
            refresh_token_hash = generate_password_hash(refresh_token_str)
            
            refresh_token = RefreshToken(
                user_id=user.id,
                token_hash=refresh_token_hash,
                user_agent=request.headers.get('User-Agent', '')[:500],
                ip_address=request.remote_addr,
                expires_at=datetime.utcnow() + current_app.config['JWT_REFRESH_TOKEN_EXPIRES']
            )
            
            db.session.add(refresh_token)
            db.session.commit()
            
            logger.info(f"Tokens generated for user: {user.email}")
            
            return {
                'access_token': access_token,
                'refresh_token': refresh_token_str,
                'token_type': 'Bearer',
                'expires_in': int(current_app.config['JWT_ACCESS_TOKEN_EXPIRES'].total_seconds()),
            }
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Token generation error: {str(e)}")
            raise
    
    @staticmethod
    def verify_token(token):
        """
        Verify JWT token and return payload.
        
        Args:
            token: JWT token string
            
        Returns:
            tuple (success, payload or error_message)
        """
        try:
            payload = jwt.decode(
                token,
                current_app.config['JWT_SECRET_KEY'],
                algorithms=['HS256']
            )
            return True, payload

        except jwt.ExpiredSignatureError as e:
            logger.warning(f"Token expired: {str(e)}")
            return False, "Токен просрочен"

        except jwt.InvalidSignatureError as e:
            logger.warning(f"Invalid token signature: {str(e)}")
            return False, "Неверная подпись токена"

        except jwt.DecodeError as e:
            logger.warning(f"Token decode error: {str(e)}")
            return False, "Неверный токен"

        except jwt.InvalidTokenError as e:
            # Catch-all for other PyJWT invalid token errors
            logger.warning(f"Invalid token: {type(e).__name__}: {str(e)}")
            return False, "Неверный токен"
        
        except Exception as e:
            # Unexpected errors
            logger.error(f"Unexpected error verifying token: {type(e).__name__}: {str(e)}")
            return False, "Неверный токен"
    
    @staticmethod
    def refresh_tokens(refresh_token_str):
        """
        Generate new access token using refresh token.
        
        Args:
            refresh_token_str: Refresh token string
            
        Returns:
            tuple (success, tokens_dict or error_message)
        """
        try:
            # Find refresh token (we need to check hash)
            refresh_tokens = RefreshToken.query.filter(
                RefreshToken.is_revoked == False,
                RefreshToken.expires_at > datetime.utcnow()
            ).all()
            
            valid_token = None
            for token in refresh_tokens:
                if check_password_hash(token.token_hash, refresh_token_str):
                    valid_token = token
                    break
            
            if not valid_token:
                logger.warning("Invalid or expired refresh token")
                return False, "Недействительный или просроченный refresh-токен"
            
            user = User.query.get(valid_token.user_id)
            if not user or not user.is_active:
                logger.warning(f"User not found or inactive: {valid_token.user_id}")
                return False, "Пользователь не найден или неактивен"
            
            # Update last_used
            valid_token.last_used = datetime.utcnow()
            db.session.commit()
            
            # Generate new access token
            tokens = AuthService.generate_tokens(user)
            tokens['refresh_token'] = refresh_token_str  # Return the same refresh token
            
            logger.info(f"Tokens refreshed for user: {user.email}")
            return True, tokens
            
        except Exception as e:
            logger.error(f"Token refresh error: {str(e)}")
            return False, "Обновление токенов не удалось"
    
    @staticmethod
    def revoke_token(refresh_token_str):
        """
        Revoke a refresh token (logout).
        
        Args:
            refresh_token_str: Refresh token to revoke
            
        Returns:
            bool: Success
        """
        try:
            refresh_tokens = RefreshToken.query.filter_by(is_revoked=False).all()
            
            for token in refresh_tokens:
                if check_password_hash(token.token_hash, refresh_token_str):
                    token.is_revoked = True
                    token.revoked_at = datetime.utcnow()
                    db.session.commit()
                    logger.info(f"Token revoked for user: {token.user_id}")
                    return True
            
            return False
            
        except Exception as e:
            logger.error(f"Token revocation error: {str(e)}")
            return False


def token_required(f):
    """Decorator to require JWT token for API endpoints."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = None

        # Check for token in Authorization header first
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            try:
                token = auth_header.split(" ")[1]
            except IndexError:
                return {'message': 'Неверный формат токена'}, 401

        # Fallback: check for access token in HttpOnly cookie
        if not token:
            try:
                cookie_name = current_app.config.get('ACCESS_TOKEN_COOKIE_NAME', 'rentit_access_token')
                token = request.cookies.get(cookie_name)
            except Exception:
                token = None

        if not token:
            return {'message': 'Токен отсутствует'}, 401
        
        success, payload = AuthService.verify_token(token)
        if not success:
            return {'message': payload}, 401
        
        # Add user info to request context
        request.user_id = payload['user_id']
        request.user_email = payload['email']
        
        return f(*args, **kwargs)
    
    return decorated_function
