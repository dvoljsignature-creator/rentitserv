"""
TOTP (Time-based One-Time Password) service module.
Handles two-factor authentication with email and authenticator app.
"""
import pyotp
import qrcode
import secrets
from io import BytesIO
import base64
from datetime import datetime, timedelta
from app.models import db, User, TOTPSettings
from app.services.email_service import EmailService
from logging_config import get_logger

logger = get_logger(__name__)

class TOTPService:
    """Service for TOTP operations."""
    
    @staticmethod
    def generate_secret():
        """
        Generate a new TOTP secret.
        
        Returns:
            str: Base32 encoded secret
        """
        return pyotp.random_base32()
    
    @staticmethod
    def get_totp_provisioning_uri(secret, email, issuer='RentIT'):
        """
        Get provisioning URI for QR code.
        
        Args:
            secret: TOTP secret
            email: User email
            issuer: Issuer name
            
        Returns:
            str: Provisioning URI
        """
        totp = pyotp.TOTP(secret)
        return totp.provisioning_uri(name=email, issuer_name=issuer)
    
    @staticmethod
    def get_qr_code(provisioning_uri):
        """
        Generate QR code image for provisioning URI.
        
        Args:
            provisioning_uri: Provisioning URI
            
        Returns:
            str: Base64 encoded QR code image
        """
        try:
            qr = qrcode.QRCode(version=1, box_size=10, border=5)
            qr.add_data(provisioning_uri)
            qr.make(fit=True)

            # Try to use Pillow-backed image factory for widest compatibility
            try:
                from qrcode.image.pil import PilImage
                img = qr.make_image(image_factory=PilImage, fill_color="black", back_color="white")
            except Exception:
                # Fallback to default factory
                img = qr.make_image(fill_color="black", back_color="white")

            # Convert to base64. Some image factory implementations (e.g., PyPNG)
            # expect different save() signatures and do not accept `format` kwarg.
            buffer = BytesIO()
            try:
                # Preferred: Pillow Image accepts format
                img.save(buffer, format='PNG')
            except TypeError:
                # Fallback: call save without format kwarg
                try:
                    img.save(buffer)
                except Exception:
                    # As a last resort, if the image factory provides `to_png`
                    if hasattr(img, 'to_png'):
                        png_bytes = img.to_png()
                        buffer.write(png_bytes)
                    else:
                        raise

            buffer.seek(0)
            img_base64 = base64.b64encode(buffer.getvalue()).decode()

            logger.info("QR code generated successfully")
            return f"data:image/png;base64,{img_base64}"

        except Exception as e:
            logger.error(f"QR code generation error: {type(e).__name__}: {str(e)}")
            return None
    
    @staticmethod
    def verify_totp(secret, code, window=1):
        """
        Verify TOTP code.
        
        Args:
            secret: TOTP secret
            code: Code to verify (6 digits)
            window: Time window for verification (+/- window)
            
        Returns:
            bool: True if code is valid
        """
        try:
            totp = pyotp.TOTP(secret)
            return totp.verify(code, valid_window=window)
        except Exception as e:
            logger.error(f"TOTP verification error: {str(e)}")
            return False
    
    @staticmethod
    def generate_backup_codes(count=10):
        """
        Generate backup codes for account recovery.
        
        Args:
            count: Number of codes to generate
            
        Returns:
            list: List of backup codes
        """
        codes = [secrets.token_urlsafe(6).upper() for _ in range(count)]
        logger.info(f"Generated {count} backup codes")
        return codes
    
    @staticmethod
    def setup_email_totp(user_id):
        """
        Setup email-based TOTP.
        
        Args:
            user_id: User ID
            
        Returns:
            tuple (success, email_code or error_message)
        """
        try:
            user = User.query.get(user_id)
            if not user:
                logger.warning(f"User not found: {user_id}")
                return False, "User not found"
            
            # Generate code
            code = ''.join([str(secrets.randbelow(10)) for _ in range(6)])
            
            # Store temporarily (in production, use Redis or similar)
            # Ensure a TOTPSettings record exists. The `secret` column is
            # non-nullable in the model, so provide an empty string for
            # email-based TOTP entries and mark the type accordingly.
            totp_settings = user.totp_settings
            if not totp_settings:
                # Create a record with empty app secret but email enabled
                totp_settings = TOTPSettings(user_id=user_id, secret='', totp_type='email')
            else:
                # Preserve existing app secret if present; update totp_type to reflect both
                existing_type = getattr(totp_settings, 'totp_type', None)
                if existing_type == 'app':
                    totp_settings.totp_type = 'both'
                elif existing_type == 'email':
                    totp_settings.totp_type = 'email'
                elif existing_type == 'both':
                    totp_settings.totp_type = 'both'
                else:
                    totp_settings.totp_type = 'email'

            totp_settings.email_totp_secret = code

            db.session.add(totp_settings)
            db.session.commit()
            
            # Send email
            subject = "RentIT: Your TOTP Code"
            body = f"Your verification code is: {code}\n\nThis code will expire in 10 minutes."
            html = f"""
            <html>
            <body>
                <h2>Email Verification Code</h2>
                <p>Your verification code is:</p>
                <h1>{code}</h1>
                <p>This code will expire in 10 minutes.</p>
                <p><strong>Do not share this code with anyone.</strong></p>
            </body>
            </html>
            """
            
            success, msg = EmailService.send_email(user.email, subject, body, html)
            
            if success:
                logger.info(f"Email TOTP code sent to: {user.email}")
                return True, code
            else:
                # Fallback: Log code when email fails
                # This allows users to see the code in logs/terminal if SMTP not configured
                logger.warning(f"Email TOTP send failed for {user.email}: {msg}")
                logger.warning(f"[TOTP CODE FALLBACK] User: {user.email}, Code: {code}")
                # Still return success so the code is stored in DB
                # The code will be in logs/terminal and user can retrieve it from there
                print(f"[TOTP CODE] For user {user.email}: {code}")
                return True, code
                
        except Exception as e:
            db.session.rollback()
            logger.error(f"Email TOTP setup error: {str(e)}")
            return False, "Setup failed"
    
    @staticmethod
    def verify_email_totp(user_id, code):
        """
        Verify email-based TOTP code.
        
        Args:
            user_id: User ID
            code: Code to verify
            
        Returns:
            tuple (success, message)
        """
        try:
            user = User.query.get(user_id)
            if not user or not user.totp_settings:
                logger.warning(f"User or TOTP settings not found: {user_id}")
                return False, "TOTP not setup"
            
            totp_settings = user.totp_settings
            
            # Verify code
            if totp_settings.email_totp_secret != code:
                logger.warning(f"Invalid email TOTP code for user: {user_id}")
                return False, "Invalid code"
            
            # Clear the code
            totp_settings.email_totp_secret = None
            totp_settings.is_verified = True
            totp_settings.verified_at = datetime.utcnow()
            
            user.totp_enabled = True
            # If settings indicate both methods, keep that; otherwise mark email
            user.totp_type = 'both' if getattr(totp_settings, 'totp_type', None) == 'both' else 'email'
            
            db.session.commit()
            
            logger.info(f"Email TOTP verified for user: {user.email}")
            return True, "TOTP verified successfully"
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Email TOTP verification error: {str(e)}")
            return False, "Verification failed"
    
    @staticmethod
    def setup_app_totp(user_id):
        """
        Setup authenticator app TOTP.
        
        Args:
            user_id: User ID
            
        Returns:
            tuple (success, {secret, qr_code, backup_codes} or error_message)
        """
        try:
            user = User.query.get(user_id)
            if not user:
                logger.warning(f"User not found: {user_id}")
                return False, "User not found"
            
            # Generate secret
            secret = TOTPService.generate_secret()
            
            # Get provisioning URI
            provisioning_uri = TOTPService.get_totp_provisioning_uri(secret, user.email)
            
            # Generate QR code
            qr_code = TOTPService.get_qr_code(provisioning_uri)
            
            # Generate backup codes
            backup_codes = TOTPService.generate_backup_codes()
            
            # Store or update in TOTP settings (not verified yet)
            totp_settings = user.totp_settings
            if not totp_settings:
                totp_settings = TOTPSettings(
                    user_id=user_id,
                    totp_type='app',
                    secret=secret
                )
            else:
                # Preserve existing email-related fields if present
                existing_type = getattr(totp_settings, 'totp_type', None)
                if existing_type == 'email':
                    totp_settings.totp_type = 'both'
                elif existing_type == 'app':
                    totp_settings.totp_type = 'app'
                elif existing_type == 'both':
                    totp_settings.totp_type = 'both'
                else:
                    totp_settings.totp_type = 'app'
                totp_settings.secret = secret

            totp_settings.backup_codes = ','.join(backup_codes)
            
            db.session.add(totp_settings)
            db.session.commit()
            
            logger.info(f"App TOTP setup initiated for user: {user.email}")
            
            return True, {
                'secret': secret,
                'qr_code': qr_code,
                'backup_codes': backup_codes,
                'provisioning_uri': provisioning_uri,
            }
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"App TOTP setup error: {str(e)}")
            return False, "Setup failed"
    
    @staticmethod
    def verify_app_totp(user_id, code):
        """
        Verify authenticator app TOTP code.
        
        Args:
            user_id: User ID
            code: 6-digit code from authenticator
            
        Returns:
            tuple (success, message)
        """
        try:
            user = User.query.get(user_id)
            if not user or not user.totp_settings:
                logger.warning(f"User or TOTP settings not found: {user_id}")
                return False, "TOTP not setup"
            
            totp_settings = user.totp_settings
            
            # Verify code
            is_valid = TOTPService.verify_totp(totp_settings.secret, code)
            
            if not is_valid:
                logger.warning(f"Invalid app TOTP code for user: {user_id}")
                return False, "Invalid code"
            
            # Mark as verified
            totp_settings.is_verified = True
            totp_settings.verified_at = datetime.utcnow()
            
            user.totp_enabled = True
            # Preserve 'both' if settings indicate both, otherwise set to app
            user.totp_type = 'both' if getattr(totp_settings, 'totp_type', None) == 'both' else 'app'
            
            db.session.commit()
            
            logger.info(f"App TOTP verified for user: {user.email}")
            return True, "TOTP verified successfully"
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"App TOTP verification error: {str(e)}")
            return False, "Verification failed"
    
    @staticmethod
    def verify_login_totp(user_id, code):
        """
        Verify TOTP during login.
        
        Args:
            user_id: User ID
            code: Code to verify
            
        Returns:
            tuple (success, message)
        """
        try:
            user = User.query.get(user_id)
            if not user or not user.totp_settings or not user.totp_enabled:
                logger.warning(f"User or TOTP not enabled: {user_id}")
                return False, "TOTP not enabled"
            
            totp_settings = user.totp_settings

            # Verify based on what secrets/fields are present. This supports
            # 'app', 'email', and 'both' stored in totp_type by checking the
            # actual fields rather than relying solely on the string flag.
            is_valid = False

            try:
                # If an app secret is present, attempt app verification first
                if getattr(totp_settings, 'secret', None):
                    try:
                        from config import get_config
                        cfg = get_config()
                        window = getattr(cfg, 'TOTP_WINDOW', 1)
                    except Exception:
                        window = 1

                    if TOTPService.verify_totp(totp_settings.secret, code, window=window):
                        is_valid = True

                    # If not valid as app code, check backup codes
                    if not is_valid and getattr(totp_settings, 'backup_codes', None):
                        codes = [c.strip().upper() for c in (totp_settings.backup_codes or '').split(',') if c.strip()]
                        if code.strip().upper() in codes:
                            # Consume the used backup code
                            codes.remove(code.strip().upper())
                            totp_settings.backup_codes = ','.join(codes) if codes else None
                            db.session.add(totp_settings)
                            db.session.commit()
                            is_valid = True

                # If still not valid, and an email OTP was generated/stored, check it
                if not is_valid and getattr(totp_settings, 'email_totp_secret', None):
                    if totp_settings.email_totp_secret == code:
                        # Clear the temporary email code after successful use
                        totp_settings.email_totp_secret = None
                        totp_settings.is_verified = True
                        totp_settings.verified_at = datetime.utcnow()
                        user.totp_enabled = True
                        # If both methods are present, keep 'both'
                        user.totp_type = 'both' if getattr(totp_settings, 'totp_type', None) == 'both' else 'email'
                        db.session.add(totp_settings)
                        db.session.add(user)
                        db.session.commit()
                        is_valid = True
            except Exception as e:
                logger.error(f"Error during login TOTP verification for user {user_id}: {str(e)}")
                return False, "Verification failed"

            if not is_valid:
                logger.warning(f"Invalid TOTP code during login: {user_id}")
                return False, "Invalid code"

            logger.info(f"TOTP verified during login for user: {user.email}")
            return True, "TOTP verified"
            
        except Exception as e:
            logger.error(f"Login TOTP verification error: {str(e)}")
            return False, "Verification failed"
    
    @staticmethod
    def verify_email_code(secret, code):
        """Verify email-based code (simple match for now)."""
        # In this simplified implementation we compare the provided code to
        # the stored temporary `email_totp_secret` on the user's TOTP settings.
        try:
            # `secret` argument isn't used for email codes; callers may pass
            # the TOTPSettings.secret accidentally. Normalize and compare.
            return secret == code
        except Exception:
            return False
    
    @staticmethod
    def disable_totp(user_id):
        """
        Disable TOTP for user.
        
        Args:
            user_id: User ID
            
        Returns:
            tuple (success, message)
        """
        try:
            user = User.query.get(user_id)
            if not user:
                logger.warning(f"User not found: {user_id}")
                return False, "User not found"
            
            user.totp_enabled = False
            user.totp_type = None
            
            if user.totp_settings:
                db.session.delete(user.totp_settings)
            
            db.session.commit()
            
            logger.info(f"TOTP disabled for user: {user.email}")
            return True, "TOTP disabled successfully"
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"TOTP disable error: {str(e)}")
            return False, "Disable failed"
