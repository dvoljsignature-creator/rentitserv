"""
Password reset service module.
Handles password reset flow.
"""
from datetime import datetime, timedelta
import secrets
from app.models import db, User
from app.services.email_service import EmailService
from app.services.auth_service import PasswordValidator
from logging_config import get_logger

logger = get_logger(__name__)


class PasswordResetService:
    """Service for password reset operations."""
    
    @staticmethod
    def request_password_reset(email):
        """
        Request password reset.
        
        Args:
            email: User email
            
        Returns:
            tuple (success, message)
        """
        try:
            user = User.query.filter_by(email=email).first()
            
            if not user:
                # Don't reveal if email exists for security
                logger.warning(f"Password reset requested for non-existent email: {email}")
                return True, "Если электронная почта существует, ссылка для сброса будет отправлена"
            
            # Generate reset token
            reset_token = secrets.token_urlsafe(32)
            user.reset_token = reset_token
            user.reset_token_expires = datetime.utcnow() + timedelta(hours=1)
            
            db.session.commit()
            
            # Send reset email
            reset_url = f"https://lirili-larila.ru/reset-password?token={reset_token}"
            
            success, msg = EmailService.send_password_reset_email(user.email, reset_url)
            
            if success:
                logger.info(f"Password reset email sent to: {email}")
                return True, "Ссылка для сброса пароля отправлена на вашу почту"
            else:
                logger.error(f"Failed to send password reset email: {msg}")
                return False, "Не удалось отправить ссылку для сброса"
                
        except Exception as e:
            db.session.rollback()
            logger.error(f"Password reset request error: {str(e)}")
            return False, "Ошибка запроса"
    
    @staticmethod
    def verify_reset_token(token):
        """
        Verify password reset token.
        
        Args:
            token: Reset token
            
        Returns:
            tuple (success, user or error_message)
        """
        try:
            user = User.query.filter_by(reset_token=token).first()
            
            if not user:
                logger.warning("Invalid reset token")
                return False, "Неверный токен для сброса"
            
            if not user.reset_token_expires or user.reset_token_expires < datetime.utcnow():
                logger.warning("Reset token expired")
                return False, "Токен для сброса просрочен"
            
            logger.info(f"Reset token verified for user: {user.email}")
            return True, user
            
        except Exception as e:
            logger.error(f"Reset token verification error: {str(e)}")
            return False, str(e)
    
    @staticmethod
    def reset_password(token, new_password):
        """
        Reset user password.
        
        Args:
            token: Reset token
            new_password: New password
            
        Returns:
            tuple (success, message)
        """
        try:
            # Verify token
            success, result = PasswordResetService.verify_reset_token(token)
            
            if not success:
                return False, result
            
            user = result
            
            # Validate password
            is_valid, error_msg = PasswordValidator.validate(new_password)
            if not is_valid:
                logger.warning(f"Invalid password for reset: {error_msg}")
                return False, error_msg
            
            # Update password
            user.set_password(new_password)
            user.reset_token = None
            user.reset_token_expires = None
            
            db.session.commit()
            
            logger.info(f"Password reset successfully for user: {user.email}")
            return True, "Пароль успешно сброшен"
            
        except Exception as e:
            db.session.rollback()
            logger.error(f"Password reset error: {str(e)}")
            return False, "Сброс пароля не удался"
