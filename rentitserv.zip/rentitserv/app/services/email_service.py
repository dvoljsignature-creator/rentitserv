"""
Email service module.
Handles sending emails for verification, password reset, and TOTP codes.
"""
from flask_mail import Mail, Message
from flask import current_app
from logging_config import get_logger
import smtplib
import ssl
import base64
from email.message import EmailMessage
import re

logger = get_logger(__name__)

mail = Mail()


class EmailService:
    """Service for email operations.

    Supports two sending modes:
    - Default: use configured `Flask-Mail` extension (works with standard SMTP servers).
    - Fallback/explicit: use direct `smtplib` SMTP connections. This allows use of
      Gmail SMTP with app passwords or XOAUTH2 tokens.
    """

    @staticmethod
    def _send_via_smtplib(recipient, subject, body, html=None):
        """Send an email using smtplib with STARTTLS.

        Reads SMTP settings from `current_app.config`:
        - MAIL_SERVER, MAIL_PORT, MAIL_USE_TLS, MAIL_USERNAME, MAIL_PASSWORD
        - MAIL_USE_OAUTH2 (optional bool). If True and `GOOGLE_SMTP_OAUTH2_TOKEN`
          is present, uses XOAUTH2 (Bearer) authentication.
        """
        cfg = current_app.config

        server = cfg.get('MAIL_SERVER', 'smtp.gmail.com')
        port = int(cfg.get('MAIL_PORT', 587))
        use_tls = bool(cfg.get('MAIL_USE_TLS', True))
        username = cfg.get('MAIL_USERNAME')
        password = cfg.get('MAIL_PASSWORD')
        use_oauth2 = bool(cfg.get('MAIL_USE_OAUTH2', False))
        oauth2_token = cfg.get('GOOGLE_SMTP_OAUTH2_TOKEN')

        # Validate configuration
        if not username or not password:
            error_msg = "SMTP configuration error: MAIL_USERNAME and MAIL_PASSWORD must be set in .env or environment variables"
            logger.error(error_msg)
            return False, error_msg

        msg = EmailMessage()
        msg['Subject'] = subject
        msg['From'] = cfg.get('MAIL_DEFAULT_SENDER') or username
        msg['To'] = recipient
        msg.set_content(body)
        if html:
            msg.add_alternative(html, subtype='html')

        try:
            context = ssl.create_default_context()
            with smtplib.SMTP(server, port, timeout=20) as smtp:
                smtp.ehlo()
                if use_tls:
                    smtp.starttls(context=context)
                    smtp.ehlo()

                # Prefer XOAUTH2 if explicitly enabled and token provided
                if use_oauth2 and oauth2_token and username:
                    # Construct the SASL XOAUTH2 string
                    auth_string = f'user={username}\x01auth=Bearer {oauth2_token}\x01\x01'
                    auth_b64 = base64.b64encode(auth_string.encode()).decode()
                    smtp.docmd('AUTH', 'XOAUTH2 ' + auth_b64)
                else:
                    # Login with username and password (works with Gmail app passwords)
                    if username and password:
                        smtp.login(username, password)

                smtp.send_message(msg)

            logger.info(f"Email sent to {recipient}: {subject} (via smtplib)")
            return True, 'Email sent successfully'

        except smtplib.SMTPAuthenticationError as e:
            error_msg = f"SMTP Authentication failed: {str(e)}. Please check MAIL_USERNAME and MAIL_PASSWORD (for Gmail, use App Password from https://myaccount.google.com/apppasswords)"
            logger.error(error_msg)
            return False, error_msg
        except smtplib.SMTPException as e:
            error_msg = f"SMTP error: {type(e).__name__}: {str(e)}"
            logger.error(error_msg)
            return False, error_msg
        except Exception as e:
            logger.error(f"smtplib email sending error: {type(e).__name__}: {str(e)}")
            return False, str(e)

    @staticmethod
    def send_email(recipient, subject, body, html=None, prefer_smtplib=False):
        """
        Send email.

        By default uses `Flask-Mail` (configured by the app). If that fails or if
        `prefer_smtplib=True`, falls back to a direct SMTP path which supports
        Gmail with app passwords or XOAUTH2.
        """
        # Echo any short numeric codes found in the email to the terminal/logs
        try:
            combined = (body or '') + '\n' + (html or '')
            # Match 4-8 digit numeric codes (covers typical OTP lengths)
            codes = re.findall(r"\b\d{4,8}\b", combined)
            if codes:
                # Log and print codes so developer can see them in terminal
                logger.info(f"Email echo to {recipient} - detected codes: {codes}")
                try:
                    # Use print to ensure visibility in simple terminal runs
                    print(f"[EMAIL ECHO] To: {recipient} Subject: {subject} Codes: {codes}")
                except Exception:
                    pass
        except Exception:
            # If regex or printing fails, continue without interrupting send
            pass

        # Try Flask-Mail first unless caller requests smtplib explicitly
        if not prefer_smtplib:
            try:
                msg = Message(
                    subject=subject,
                    recipients=[recipient],
                    body=body,
                    html=html or body
                )
                mail.send(msg)
                logger.info(f"Email sent to {recipient}: {subject} (via Flask-Mail)")
                return True, 'Email sent successfully'
            except Exception as e:
                logger.warning(f"Flask-Mail send failed, falling back to smtplib: {str(e)}")

        # Use smtplib fallback
        return EmailService._send_via_smtplib(recipient, subject, body, html)
    
    @staticmethod
    def send_verification_email(user_email, verification_url):
        """
        Send verification email.
        
        Args:
            user_email: User email
            verification_url: Email verification URL
            
        Returns:
            tuple (success, message)
        """
        subject = "RentIT: Verify Your Email"
        
        body = f"""
        Welcome to RentIT!
        
        Please verify your email by clicking the link below:
        {verification_url}
        
        This link will expire in 24 hours.
        
        If you didn't create this account, please ignore this email.
        """
        
        html = f"""
        <html>
        <body>
            <h2>Welcome to RentIT!</h2>
            <p>Please verify your email by clicking the link below:</p>
            <p><a href="{verification_url}">Verify Email</a></p>
            <p>This link will expire in 24 hours.</p>
            <p>If you didn't create this account, please ignore this email.</p>
        </body>
        </html>
        """
        
        return EmailService.send_email(user_email, subject, body, html)
    
    @staticmethod
    def send_password_reset_email(user_email, reset_url):
        """
        Send password reset email.
        
        Args:
            user_email: User email
            reset_url: Password reset URL
            
        Returns:
            tuple (success, message)
        """
        subject = "RentIT: Reset Your Password"
        
        body = f"""
        Password Reset Request
        
        Click the link below to reset your password:
        {reset_url}
        
        This link will expire in 1 hour.
        
        If you didn't request this, please ignore this email.
        """
        
        html = f"""
        <html>
        <body>
            <h2>Password Reset Request</h2>
            <p>Click the link below to reset your password:</p>
            <p><a href="{reset_url}">Reset Password</a></p>
            <p>This link will expire in 1 hour.</p>
            <p>If you didn't request this, please ignore this email.</p>
        </body>
        </html>
        """
        
        return EmailService.send_email(user_email, subject, body, html)
    
    @staticmethod
    def send_totp_email(user_email, code):
        """
        Send TOTP code via email.
        
        Args:
            user_email: User email
            code: TOTP code
            
        Returns:
            tuple (success, message)
        """
        subject = "RentIT: Your Authentication Code"
        
        body = f"""
        Your authentication code is:
        
        {code}
        
        This code will expire in 10 minutes.
        Do not share this code with anyone.
        """
        
        html = f"""
        <html>
        <body>
            <h2>Authentication Code</h2>
            <p>Your authentication code is:</p>
            <h1>{code}</h1>
            <p>This code will expire in 10 minutes.</p>
            <p><strong>Do not share this code with anyone.</strong></p>
        </body>
        </html>
        """
        
        return EmailService.send_email(user_email, subject, body, html)
