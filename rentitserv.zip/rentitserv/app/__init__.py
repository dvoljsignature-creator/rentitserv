"""
Flask application factory.
"""
from flask import Flask, request, render_template, redirect, url_for
from flask_cors import CORS
from config import get_config
from app.models import db
from app.services import mail
from app.views import auth_bp, totp_bp, password_bp, oauth_bp
from app.views.clients_views import clients_bp
from app.views.employees_views import employees_bp
from app.views.inventory_views import inventory_bp
from app.views.kits_views import kits_bp
from app.views.rentals_views import rentals_bp
from logging_config import setup_logging
import logging
from sqlalchemy import text

logger = logging.getLogger('rentit')


def create_app(config=None):
    """
    Create and configure Flask application.
    
    Args:
        config: Configuration object (optional)
        
    Returns:
        Flask application instance
    """
    # Setup logging first
    setup_logging()
    
    app = Flask(__name__)
    
    # Load configuration
    if config is None:
        config = get_config()
    
    app.config.from_object(config)
    
    logger.info(f"Creating Flask app with {config.__class__.__name__} config")
    
    # Initialize extensions
    db.init_app(app)
    mail.init_app(app)
    CORS(app)
    
    # Register blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(totp_bp)
    app.register_blueprint(password_bp)
    app.register_blueprint(oauth_bp)
    app.register_blueprint(clients_bp)
    app.register_blueprint(employees_bp)
    app.register_blueprint(inventory_bp)
    app.register_blueprint(kits_bp)
    app.register_blueprint(rentals_bp)
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        """Handle 404 errors."""
        logger.warning(f"404 error: {request.path}")
        return {'error': 'Not found'}, 404
    
    @app.errorhandler(400)
    def bad_request(error):
        """Handle 400 errors."""
        logger.warning(f"400 error: {str(error)}")
        return {'error': 'Bad request'}, 400
    
    @app.errorhandler(500)
    def internal_error(error):
        """Handle 500 errors."""
        logger.error(f"500 error: {str(error)}")
        return {'error': 'Internal server error'}, 500
    
    # Create database tables
    with app.app_context():
        db.create_all()
        # Ensure legacy column `client_name` exists on rentals table (some DBs created before this field was added)
        try:
            conn = db.engine.connect()
            res = conn.execute(text("PRAGMA table_info('rentals')")).fetchall()
            cols = [r[1] for r in res]
            if 'client_name' not in cols:
                app.logger.info('Adding missing column `client_name` to rentals table')
                conn.execute(text("ALTER TABLE rentals ADD COLUMN client_name TEXT"))
            # ensure status column exists (legacy DBs may require it)
            if 'status' not in cols:
                app.logger.info('Adding missing column `status` to rentals table')
                # Add column with default so existing rows get a value
                conn.execute(text("ALTER TABLE rentals ADD COLUMN status TEXT DEFAULT 'active' NOT NULL"))
                # commit for SQLite via connection
            conn.close()
        except Exception as e:
            app.logger.warning(f'Could not ensure rentals.client_name column: {e}')
        logger.info("Database tables created")
    
    # Health check endpoint
    @app.route('/health', methods=['GET'])
    def health():
        """Health check endpoint."""
        return {'status': 'ok'}, 200
    
    # HTML Pages
    @app.route('/', methods=['GET'])
    def index():
        """Home page."""
        # If a password reset token is provided, go to reset page.
        if request.args.get('token'):
            return redirect(url_for('reset_password_page'))
        # By default open the login page when visiting the site root
        return redirect(url_for('login_page'))
    
    @app.route('/login', methods=['GET'])
    def login_page():
        """Login page."""
        return render_template('login.html')
    
    @app.route('/register', methods=['GET'])
    def register_page():
        """Registration page."""
        return render_template('register.html')
    
    @app.route('/forgot-password', methods=['GET'])
    def forgot_password_page():
        """Forgot password page."""
        return render_template('forgot_password.html')
    
    @app.route('/reset-password', methods=['GET'])
    def reset_password_page():
        """Reset password page."""
        return render_template('reset_password.html')
    
    @app.route('/totp-verify', methods=['GET'])
    def totp_verify_page():
        """TOTP verification page."""
        return render_template('totp_verify.html')
    
    @app.route('/totp-verify-email', methods=['GET'])
    def totp_verify_email_page():
        """TOTP email verification page."""
        return render_template('totp_verify_email.html')
    
    @app.route('/totp-setup', methods=['GET'])
    def totp_setup_page():
        """TOTP setup page."""
        return render_template('totp_setup.html')
    
    @app.route('/dashboard', methods=['GET'])
    def dashboard_page():
        """User dashboard."""
        return render_template('dashboard.html')
    
    @app.route('/resources', methods=['GET'])
    def resources_page():
        """Resources management page (employees, inventory, kits)."""
        return render_template('resources.html')
    
    logger.info("Flask app created successfully")
    
    return app
