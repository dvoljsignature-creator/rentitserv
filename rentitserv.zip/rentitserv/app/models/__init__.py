"""
Database models for RentIT application.
"""
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from werkzeug.security import generate_password_hash, check_password_hash
import uuid
import os

db = SQLAlchemy()


class User(db.Model):
    """User model with authentication support."""
    __tablename__ = 'users'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    username = db.Column(db.String(100), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=True)
    first_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    
    # Account status
    is_active = db.Column(db.Boolean, default=True)
    is_verified = db.Column(db.Boolean, default=False)
    verification_token = db.Column(db.String(255), unique=True, nullable=True)
    verification_token_expires = db.Column(db.DateTime, nullable=True)
    
    # TOTP Settings
    totp_enabled = db.Column(db.Boolean, default=False)
    totp_type = db.Column(db.String(50), default=None)  # 'email' or 'app'
    
    # Google OAuth
    google_id = db.Column(db.String(255), unique=True, nullable=True, index=True)
    google_email = db.Column(db.String(255), nullable=True)
    
    # Password reset
    reset_token = db.Column(db.String(255), unique=True, nullable=True)
    reset_token_expires = db.Column(db.DateTime, nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    last_login = db.Column(db.DateTime, nullable=True)
    
    # Relationships
    totp_settings = db.relationship('TOTPSettings', backref='user', uselist=False, cascade='all, delete-orphan')
    refresh_tokens = db.relationship('RefreshToken', backref='user', cascade='all, delete-orphan')
    
    def set_password(self, password):
        """Hash and set password."""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check password against hash."""
        if not self.password_hash:
            return False
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'


class TOTPSettings(db.Model):
    """TOTP settings for two-factor authentication."""
    __tablename__ = 'totp_settings'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id', ondelete='CASCADE'), unique=True, nullable=False, index=True)
    
    # TOTP secret (encrypted)
    secret = db.Column(db.String(255), nullable=False)
    
    # Backup codes (encrypted, comma-separated)
    backup_codes = db.Column(db.Text, nullable=True)
    
    # TOTP type
    totp_type = db.Column(db.String(50), nullable=False)  # 'email' or 'app'
    
    # Status
    is_verified = db.Column(db.Boolean, default=False)
    verified_at = db.Column(db.DateTime, nullable=True)
    
    # Email TOTP specific
    email_totp_secret = db.Column(db.String(255), nullable=True)  # For temporary email OTP storage
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    def __repr__(self):
        return f'<TOTPSettings {self.user_id}>'


class RefreshToken(db.Model):
    """Refresh tokens for JWT authentication."""
    __tablename__ = 'refresh_tokens'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    
    # Token (hashed)
    token_hash = db.Column(db.String(255), unique=True, nullable=False, index=True)
    
    # Token metadata
    user_agent = db.Column(db.String(500), nullable=True)
    ip_address = db.Column(db.String(45), nullable=True)
    
    # Status
    is_revoked = db.Column(db.Boolean, default=False)
    revoked_at = db.Column(db.DateTime, nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)
    last_used = db.Column(db.DateTime, nullable=True)
    
    def is_expired(self):
        """Check if token is expired."""
        return datetime.utcnow() > self.expires_at
    
    def __repr__(self):
        return f'<RefreshToken {self.user_id}>'


class Client(db.Model):
    """Client model for managing clients."""
    __tablename__ = 'clients'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    
    # Display number (sequential per user)
    sequence_number = db.Column(db.Integer, nullable=False)
    
    # Client information
    name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), nullable=True)
    phone = db.Column(db.String(20), nullable=True)
    address = db.Column(db.String(500), nullable=True)
    
    # Additional info
    company = db.Column(db.String(255), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    
    # Status
    is_active = db.Column(db.Boolean, default=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    def to_dict(self):
        """Convert client to dictionary."""
        return {
            'id': self.id,
            'sequence_number': self.sequence_number,
            'name': self.name,
            'email': self.email,
            'phone': self.phone,
            'address': self.address,
            'company': self.company,
            'notes': self.notes,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def __repr__(self):
        return f'<Client {self.name}>'


class Employee(db.Model):
    """Employee model for managing staff."""
    __tablename__ = 'employees'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    
    # Display number (sequential per user)
    sequence_number = db.Column(db.Integer, nullable=False)
    
    # Employee information
    first_name = db.Column(db.String(255), nullable=False)
    last_name = db.Column(db.String(255), nullable=False)
    position = db.Column(db.String(255), nullable=True)
    email = db.Column(db.String(255), nullable=True)
    phone = db.Column(db.String(20), nullable=True)
    hire_date = db.Column(db.Date, nullable=True)
    
    # Status: 'active', 'waiting', 'inactive'
    status = db.Column(db.String(20), default='active', nullable=False)
    
    # Additional info
    department = db.Column(db.String(255), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    def to_dict(self):
        """Convert employee to dictionary."""
        st = self.status if self.status != 'end_of_life' else 'inactive'
        return {
            'id': self.id,
            'sequence_number': self.sequence_number,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'position': self.position,
            'email': self.email,
            'phone': self.phone,
            'hire_date': self.hire_date.isoformat() if self.hire_date else None,
            'status': st,
            'department': self.department,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def __repr__(self):
        return f'<Employee {self.first_name} {self.last_name}>'


class Inventory(db.Model):
    """Inventory model for managing items."""
    __tablename__ = 'inventory'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    
    # Display number (sequential per user)
    sequence_number = db.Column(db.Integer, nullable=False)
    
    # Item information
    name = db.Column(db.String(255), nullable=False)
    category = db.Column(db.String(255), nullable=True)
    sku = db.Column(db.String(100), nullable=True)
    purchase_date = db.Column(db.Date, nullable=True)
    purchase_price = db.Column(db.Float, nullable=True)
    # Legacy quantity column (DB may still have this NOT NULL column). Keep it in model
    # with a safe default so inserts don't fail. We allow database default as '1'.
    quantity = db.Column(db.Integer, nullable=False, default=1, server_default='1')
    
    # New fields for inventory lifecycle
    addition_date = db.Column(db.Date, nullable=True)  # When item was added to system
    lifetime_days = db.Column(db.Integer, nullable=True)  # Lifetime in days
    disposal_date = db.Column(db.Date, nullable=True)  # Calculated: addition_date + lifetime_days
    
    # Status: depends on Kit status if item belongs to a kit.
    # Default to 'waiting' (item exists but not yet in any kit).
    status = db.Column(db.String(20), default='waiting', nullable=False)
    
    # Additional info
    location = db.Column(db.String(255), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    
    # Relationships
    kit_inventories = db.relationship('KitInventory', backref='inventory', cascade='all, delete-orphan')
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    def get_effective_status(self):
        """Get effective status based on Kit status if inventory belongs to a kit."""
        # If disposal_date is set and in the past, item is end_of_life
        try:
            if self.disposal_date:
                from datetime import date
                if isinstance(self.disposal_date, str):
                    # defensive: parse ISO string
                    from datetime import datetime
                    dd = datetime.fromisoformat(self.disposal_date).date()
                else:
                    dd = self.disposal_date
                if dd <= date.today():
                    return 'end_of_life'
        except Exception:
            pass

        # Gather related kits
        try:
            kit_entries = self.kit_inventories or []
            kits = [ki.kit for ki in kit_entries if ki and ki.kit]
        except Exception:
            # fallback to querying
            kits = [k.kit for k in db.session.query(KitInventory).filter_by(inventory_id=self.id).all() if k and k.kit]

        # Priority: if any kit is 'inactive' -> inventory 'inactive'
        for k in kits:
            if getattr(k, 'status', None) == 'inactive':
                return 'inactive'

        # If any kit is 'waiting' -> inventory 'waiting'
        for k in kits:
            if getattr(k, 'status', None) == 'waiting':
                return 'waiting'

        # If any kit is 'active' -> inventory 'active'
        for k in kits:
            if getattr(k, 'status', None) == 'active':
                return 'active'

        # Otherwise: waiting
        return 'waiting'
    
    def to_dict(self):
        """Convert inventory to dictionary."""
        return {
            'id': self.id,
            'sequence_number': self.sequence_number,
            'name': self.name,
            'category': self.category,
            'sku': self.sku,
            'purchase_date': self.purchase_date.isoformat() if self.purchase_date else None,
            'purchase_price': self.purchase_price,
            'addition_date': self.addition_date.isoformat() if self.addition_date else None,
            'lifetime_days': self.lifetime_days,
            'disposal_date': self.disposal_date.isoformat() if self.disposal_date else None,
            'status': self.get_effective_status(),
            'location': self.location,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
    
    def __repr__(self):
        return f'<Inventory {self.name}>'


class Kit(db.Model):
    """Kit model for managing equipment kits/bundles."""
    __tablename__ = 'kits'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    
    # Display number (sequential per user)
    sequence_number = db.Column(db.Integer, nullable=False)
    
    # Kit information
    name = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    
    # Status: 'active', 'waiting', 'inactive'
    status = db.Column(db.String(20), default='active', nullable=False)
    
    # Kit management
    created_date = db.Column(db.Date, default=datetime.utcnow, nullable=False)
    
    # Additional info
    location = db.Column(db.String(255), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    
    # Relationships
    kit_inventories = db.relationship('KitInventory', backref='kit', cascade='all, delete-orphan')
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    def to_dict(self, include_inventories=False):
        """Convert kit to dictionary."""
        st = self.status if self.status != 'end_of_life' else 'inactive'
        result = {
            'id': self.id,
            'sequence_number': self.sequence_number,
            'name': self.name,
            'description': self.description,
            'status': st,
            'created_date': self.created_date.isoformat() if self.created_date else None,
            'location': self.location,
            'notes': self.notes,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }
        if include_inventories:
            # keep legacy key expected by frontend
            result['kit_inventories'] = [ki.inventory.to_dict() for ki in self.kit_inventories]
            # also provide 'inventories' for compatibility
            result['inventories'] = result['kit_inventories']
        return result
    
    def __repr__(self):
        return f'<Kit {self.name}>'


class KitInventory(db.Model):
    """Association model for Kit and Inventory (many-to-many)."""
    __tablename__ = 'kit_inventory'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    kit_id = db.Column(db.String(36), db.ForeignKey('kits.id', ondelete='CASCADE'), nullable=False, index=True)
    inventory_id = db.Column(db.String(36), db.ForeignKey('inventory.id', ondelete='CASCADE'), nullable=False, index=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    
    def __repr__(self):
        return f'<KitInventory kit={self.kit_id} inventory={self.inventory_id}>'


class Rental(db.Model):
    """Rental model for scheduling kits."""
    __tablename__ = 'rentals'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)

    title = db.Column(db.String(255), nullable=False)
    client_id = db.Column(db.String(36), nullable=True)
    client_name = db.Column(db.String(255), nullable=True)

    # store kit ids as JSON text for simplicity
    kit_ids = db.Column(db.Text, nullable=True)

    # Status: 'active', 'cancelled', etc. Default to 'active'
    status = db.Column(db.String(20), default='active', nullable=False, server_default='active')

    start = db.Column(db.String(20), nullable=False)  # ISO date string YYYY-MM-DD
    end = db.Column(db.String(20), nullable=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    def to_dict(self):
        import json
        try:
            kits = json.loads(self.kit_ids) if self.kit_ids else []
        except Exception:
            kits = []
        return {
            'id': self.id,
            'title': self.title,
            'client_id': self.client_id,
            'client_name': self.client_name,
            'status': self.status,
            'kit_ids': kits,
            'start': self.start,
            'end': self.end,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

    def __repr__(self):
        return f'<Rental {self.title} ({self.start} - {self.end})>'
