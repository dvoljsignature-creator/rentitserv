"""
Employees management endpoints.
"""
from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from app.models import db, Employee
from app.services.auth_service import token_required
import logging

employees_bp = Blueprint('employees', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)


@employees_bp.route('/employees', methods=['GET'])
@cross_origin()
@token_required
def get_employees():
    """Get all employees for the current user."""
    try:
        user_id = request.user_id
        employees = Employee.query.filter_by(user_id=user_id).order_by(Employee.sequence_number).all()
        
        return jsonify({
            'success': True,
            'employees': [employee.to_dict() for employee in employees]
        }), 200
    except Exception as e:
        logger.error(f'Error getting employees: {str(e)}')
        return jsonify({'error': 'Failed to get employees'}), 500


@employees_bp.route('/employees', methods=['POST'])
@cross_origin()
@token_required
def create_employee():
    """Create a new employee."""
    try:
        user_id = request.user_id
        data = request.get_json()
        
        if not data or not data.get('first_name') or not data.get('last_name'):
            return jsonify({'error': 'First name and last name are required'}), 400
        
        # Get the next sequence number for this user
        last_employee = Employee.query.filter_by(user_id=user_id).order_by(Employee.sequence_number.desc()).first()
        next_sequence = (last_employee.sequence_number + 1) if last_employee else 1
        
        # Create new employee
        new_employee = Employee(
            user_id=user_id,
            sequence_number=next_sequence,
            first_name=data.get('first_name'),
            last_name=data.get('last_name'),
            position=data.get('position'),
            email=data.get('email'),
            phone=data.get('phone'),
            hire_date=data.get('hire_date'),
            status=(data.get('status') if data.get('status') in ('active','waiting','inactive') else 'active'),
            department=data.get('department'),
            notes=data.get('notes')
        )
        
        db.session.add(new_employee)
        db.session.commit()
        
        logger.info(f'Employee created: {new_employee.id}')
        return jsonify({
            'success': True,
            'message': 'Employee created successfully',
            'employee': new_employee.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error creating employee: {str(e)}')
        return jsonify({'error': 'Failed to create employee'}), 500


@employees_bp.route('/employees/<employee_id>', methods=['GET'])
@cross_origin()
@token_required
def get_employee(employee_id):
    """Get a specific employee."""
    try:
        user_id = request.user_id
        employee = Employee.query.filter_by(id=employee_id, user_id=user_id).first()
        
        if not employee:
            return jsonify({'error': 'Employee not found'}), 404
        
        return jsonify({
            'success': True,
            'employee': employee.to_dict()
        }), 200
    except Exception as e:
        logger.error(f'Error getting employee: {str(e)}')
        return jsonify({'error': 'Failed to get employee'}), 500


@employees_bp.route('/employees/<employee_id>', methods=['PUT'])
@cross_origin()
@token_required
def update_employee(employee_id):
    """Update an employee."""
    try:
        user_id = request.user_id
        employee = Employee.query.filter_by(id=employee_id, user_id=user_id).first()
        
        if not employee:
            return jsonify({'error': 'Employee not found'}), 404
        
        data = request.get_json()
        
        # Update fields if provided
        if 'first_name' in data:
            employee.first_name = data['first_name']
        if 'last_name' in data:
            employee.last_name = data['last_name']
        if 'position' in data:
            employee.position = data['position']
        if 'email' in data:
            employee.email = data['email']
        if 'phone' in data:
            employee.phone = data['phone']
        if 'hire_date' in data:
            employee.hire_date = data['hire_date']
        if 'status' in data:
            # prevent 'end_of_life' being set on employees; coerce to allowed values
            employee.status = data.get('status') if data.get('status') in ('active','waiting','inactive') else employee.status
        if 'department' in data:
            employee.department = data['department']
        if 'notes' in data:
            employee.notes = data['notes']
        
        db.session.commit()
        
        logger.info(f'Employee updated: {employee.id}')
        return jsonify({
            'success': True,
            'message': 'Employee updated successfully',
            'employee': employee.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error updating employee: {str(e)}')
        return jsonify({'error': 'Failed to update employee'}), 500


@employees_bp.route('/employees/<employee_id>', methods=['DELETE'])
@cross_origin()
@token_required
def delete_employee(employee_id):
    """Delete an employee."""
    try:
        user_id = request.user_id
        employee = Employee.query.filter_by(id=employee_id, user_id=user_id).first()
        
        if not employee:
            return jsonify({'error': 'Employee not found'}), 404
        
        db.session.delete(employee)
        db.session.commit()
        
        logger.info(f'Employee deleted: {employee.id}')
        return jsonify({
            'success': True,
            'message': 'Employee deleted successfully'
        }), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error deleting employee: {str(e)}')
        return jsonify({'error': 'Failed to delete employee'}), 500


@employees_bp.route('/employees/batch/delete', methods=['POST'])
@cross_origin()
@token_required
def delete_employees_batch():
    """Delete multiple employees."""
    try:
        user_id = request.user_id
        data = request.get_json()
        
        if not data or not isinstance(data.get('ids'), list):
            return jsonify({'error': 'Array of ids is required'}), 400
        
        ids = data.get('ids')
        
        # Delete employees
        deleted_count = Employee.query.filter(
            Employee.id.in_(ids),
            Employee.user_id == user_id
        ).delete()
        
        db.session.commit()
        
        logger.info(f'Deleted {deleted_count} employees')
        return jsonify({
            'success': True,
            'message': f'Successfully deleted {deleted_count} employees',
            'deleted_count': deleted_count
        }), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error deleting employees batch: {str(e)}')
        return jsonify({'error': 'Failed to delete employees'}), 500
