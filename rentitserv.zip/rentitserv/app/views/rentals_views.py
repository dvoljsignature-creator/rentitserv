"""
Rentals management endpoints.
"""
from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from app.models import db, Rental
from app.services.auth_service import token_required
import logging
import json
from datetime import datetime

rentals_bp = Blueprint('rentals', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)


@rentals_bp.route('/rentals', methods=['GET'])
@cross_origin()
@token_required
def get_rentals():
    try:
        user_id = request.user_id
        rentals = Rental.query.filter_by(user_id=user_id).all()
        return jsonify({'success': True, 'rentals': [r.to_dict() for r in rentals]}), 200
    except Exception as e:
        logger.error(f'Error getting rentals: {str(e)}')
        return jsonify({'error': 'Failed to get rentals'}), 500


@rentals_bp.route('/rentals', methods=['POST'])
@cross_origin()
@token_required
def create_rental():
    try:
        user_id = request.user_id
        data = request.get_json() or {}
        title = data.get('title') or 'Аренда'
        client_id = data.get('client_id')
        kit_ids = data.get('kit_ids') or []
        start = data.get('start')
        end = data.get('end') or start

        if not start:
            return jsonify({'error': 'start date required'}), 400

        # simple overlap check: ensure no kit is in conflicting rental
        def ranges_overlap(a_start, a_end, b_start, b_end):
            try:
                a_s = datetime.fromisoformat(a_start)
                a_e = datetime.fromisoformat(a_end)
                b_s = datetime.fromisoformat(b_start)
                b_e = datetime.fromisoformat(b_end)
            except Exception:
                return False
            return not (a_e < b_s or a_s > b_e)

        # check conflicts
        existing = Rental.query.filter_by(user_id=user_id).all()
        for r in existing:
            try:
                existing_kits = json.loads(r.kit_ids) if r.kit_ids else []
            except Exception:
                existing_kits = []
            if set(existing_kits) & set(kit_ids):
                if ranges_overlap(start, end, r.start, r.end):
                    return jsonify({'error': 'Kit conflict with existing rental'}), 400

        rental = Rental(
            user_id=user_id,
            title=title,
            client_id=client_id,
            client_name=data.get('client_name') or None,
            kit_ids=json.dumps(kit_ids),
            start=start,
            end=end
        )
        db.session.add(rental)
        db.session.commit()
        return jsonify({'success': True, 'rental': rental.to_dict()}), 201
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error creating rental: {str(e)}')
        return jsonify({'error': 'Failed to create rental'}), 500


@rentals_bp.route('/rentals/<rental_id>', methods=['PUT'])
@cross_origin()
@token_required
def update_rental(rental_id):
    try:
        user_id = request.user_id
        data = request.get_json() or {}
        rental = Rental.query.filter_by(id=rental_id, user_id=user_id).first()
        if not rental:
            return jsonify({'error': 'Rental not found'}), 404

        title = data.get('title')
        client_id = data.get('client_id')
        kit_ids = data.get('kit_ids')
        start = data.get('start')
        end = data.get('end')

        # basic conflict check excluding this rental
        def ranges_overlap(a_start, a_end, b_start, b_end):
            try:
                a_s = datetime.fromisoformat(a_start)
                a_e = datetime.fromisoformat(a_end)
                b_s = datetime.fromisoformat(b_start)
                b_e = datetime.fromisoformat(b_end)
            except Exception:
                return False
            return not (a_e < b_s or a_s > b_e)

        if kit_ids is not None and (start or rental.start) and (end or rental.end):
            all_other = Rental.query.filter(Rental.user_id == user_id, Rental.id != rental_id).all()
            for r in all_other:
                try:
                    existing_kits = json.loads(r.kit_ids) if r.kit_ids else []
                except Exception:
                    existing_kits = []
                if set(existing_kits) & set(kit_ids):
                    if ranges_overlap(start or rental.start, end or rental.end, r.start, r.end):
                        return jsonify({'error': 'Kit conflict with existing rental'}), 400

        if title is not None:
            rental.title = title
        if client_id is not None:
            rental.client_id = client_id
        if 'client_name' in data:
            rental.client_name = data.get('client_name')
        if kit_ids is not None:
            rental.kit_ids = json.dumps(kit_ids)
        if start is not None:
            rental.start = start
        if end is not None:
            rental.end = end

        db.session.commit()
        return jsonify({'success': True, 'rental': rental.to_dict()}), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error updating rental: {str(e)}')
        return jsonify({'error': 'Failed to update rental'}), 500


@rentals_bp.route('/rentals/<rental_id>', methods=['DELETE'])
@cross_origin()
@token_required
def delete_rental(rental_id):
    try:
        user_id = request.user_id
        rental = Rental.query.filter_by(id=rental_id, user_id=user_id).first()
        if not rental:
            return jsonify({'error': 'Rental not found'}), 404
        db.session.delete(rental)
        db.session.commit()
        return jsonify({'success': True}), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error deleting rental: {str(e)}')
        return jsonify({'error': 'Failed to delete rental'}), 500


@rentals_bp.route('/rentals/kit_availability', methods=['GET'])
@cross_origin()
@token_required
def kit_availability():
    try:
        user_id = request.user_id
        start = request.args.get('start')
        end = request.args.get('end') or start
        exclude = request.args.get('exclude')

        # load all rentals for user except excluded one
        query = Rental.query.filter_by(user_id=user_id)
        if exclude:
            query = query.filter(Rental.id != exclude)
        existing = query.all()

        # build map of kit id -> available (true/false)
        availability = {}

        def ranges_overlap(a_start, a_end, b_start, b_end):
            try:
                a_s = datetime.fromisoformat(a_start)
                a_e = datetime.fromisoformat(a_end)
                b_s = datetime.fromisoformat(b_start)
                b_e = datetime.fromisoformat(b_end)
            except Exception:
                return False
            return not (a_e < b_s or a_s > b_e)

        for r in existing:
            try:
                kits = json.loads(r.kit_ids) if r.kit_ids else []
            except Exception:
                kits = []
            if ranges_overlap(start, end, r.start, r.end):
                for k in kits:
                    availability[str(k)] = False

        # All other kits that are not explicitly false are available=True (frontend expects list of kits with available flag)
        # We'll return an empty list here and let frontend merge with allKits; but include per-kit availability entries.
        kits_list = [{'id': k, 'available': availability.get(str(k), True)} for k in availability.keys()]

        return jsonify({'success': True, 'kits': kits_list}), 200
    except Exception as e:
        logger.error(f'Error computing kit availability: {str(e)}')
        return jsonify({'error': 'Failed to compute availability'}), 500


@rentals_bp.route('/reports/rentals/daily', methods=['GET'])
@cross_origin()
@token_required
def rentals_daily_report():
    """Return daily counts for rentals between start and end (inclusive).

    Query params: start=YYYY-MM-DD, end=YYYY-MM-DD
    Response: { success: True, dates: [...], started: [...], active: [...], finished: [...] }
    """
    try:
        user_id = request.user_id
        start = request.args.get('start')
        end = request.args.get('end')
        if not start or not end:
            return jsonify({'error': 'start and end query params required'}), 400

        # generate date range (inclusive)
        from datetime import datetime, timedelta
        try:
            s_dt = datetime.fromisoformat(start)
            e_dt = datetime.fromisoformat(end)
        except Exception:
            return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400

        if e_dt < s_dt:
            return jsonify({'error': 'end must be >= start'}), 400

        dates = []
        started = []
        active = []
        finished = []

        cur = s_dt
        while cur <= e_dt:
            dstr = cur.date().isoformat()
            # started: rentals with start == dstr
            started_count = Rental.query.filter_by(user_id=user_id).filter(Rental.start == dstr).count()
            # finished: rentals with end == dstr
            finished_count = Rental.query.filter_by(user_id=user_id).filter(Rental.end == dstr).count()
            # active: rentals where start <= dstr <= end and status == 'active'
            active_count = Rental.query.filter(Rental.user_id == user_id, Rental.start <= dstr, Rental.end >= dstr, Rental.status == 'active').count()

            dates.append(dstr)
            started.append(started_count)
            active.append(active_count)
            finished.append(finished_count)

            cur = cur + timedelta(days=1)

        return jsonify({'success': True, 'dates': dates, 'started': started, 'active': active, 'finished': finished}), 200
    except Exception as e:
        logger.error(f'Error computing rentals daily report: {e}')
        return jsonify({'error': 'Failed to compute report'}), 500
