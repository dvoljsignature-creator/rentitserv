"""
Inventory management endpoints.
"""
from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from app.models import db, Inventory
from datetime import datetime, date, timedelta
from app.services.auth_service import token_required
import logging

inventory_bp = Blueprint('inventory', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)


@inventory_bp.route('/inventory', methods=['GET'])
@cross_origin()
@token_required
def get_inventory():
    """Get all inventory items for the current user."""
    try:
        user_id = request.user_id
        items = Inventory.query.filter_by(user_id=user_id).order_by(Inventory.sequence_number).all()
        
        return jsonify({
            'success': True,
            'inventory': [item.to_dict() for item in items]
        }), 200
    except Exception as e:
        logger.error(f'Error getting inventory: {str(e)}')
        return jsonify({'error': 'Failed to get inventory'}), 500


@inventory_bp.route('/inventory', methods=['POST'])
@cross_origin()
@token_required
def create_inventory():
    """Create a new inventory item."""
    try:
        user_id = request.user_id
        data = request.get_json()
        
        if not data or not data.get('name'):
            return jsonify({'error': 'Item name is required'}), 400
        
        # Get the next sequence number for this user
        last_item = Inventory.query.filter_by(user_id=user_id).order_by(Inventory.sequence_number.desc()).first()
        next_sequence = (last_item.sequence_number + 1) if last_item else 1
        
        # Normalize incoming date fields to Python date objects
        addition_date = data.get('addition_date')
        if addition_date:
            try:
                if isinstance(addition_date, str):
                    addition_date = datetime.fromisoformat(addition_date).date()
                elif isinstance(addition_date, datetime):
                    addition_date = addition_date.date()
            except Exception:
                addition_date = None

        lifetime_days = data.get('lifetime_days')
        try:
            lifetime_days = int(lifetime_days) if lifetime_days is not None else None
        except Exception:
            lifetime_days = None

        disposal_date = data.get('disposal_date')
        if disposal_date:
            try:
                if isinstance(disposal_date, str):
                    disposal_date = datetime.fromisoformat(disposal_date).date()
                elif isinstance(disposal_date, datetime):
                    disposal_date = disposal_date.date()
            except Exception:
                disposal_date = None

        # compute disposal_date if possible
        if not disposal_date and addition_date and lifetime_days:
            try:
                disposal_date = addition_date + timedelta(days=int(lifetime_days))
            except Exception:
                disposal_date = None

        # Create new inventory item (do not allow manual status assignment)
        new_item = Inventory(
            user_id=user_id,
            sequence_number=next_sequence,
            name=data.get('name'),
            category=data.get('category'),
            sku=data.get('sku'),
            purchase_date=data.get('purchase_date'),
            purchase_price=data.get('purchase_price'),
            addition_date=addition_date,
            lifetime_days=lifetime_days,
            disposal_date=disposal_date,
            # status will be managed automatically by `get_effective_status()`
            location=data.get('location'),
            notes=data.get('notes')
        )
        
        db.session.add(new_item)
        db.session.commit()
        
        logger.info(f'Inventory item created: {new_item.id}')
        return jsonify({
            'success': True,
            'message': 'Inventory item created successfully',
            'inventory': new_item.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error creating inventory: {str(e)}')
        return jsonify({'error': 'Failed to create inventory'}), 500


@inventory_bp.route('/inventory/<item_id>', methods=['GET'])
@cross_origin()
@token_required
def get_inventory_item(item_id):
    """Get a specific inventory item."""
    try:
        user_id = request.user_id
        item = Inventory.query.filter_by(id=item_id, user_id=user_id).first()
        
        if not item:
            return jsonify({'error': 'Inventory item not found'}), 404
        
        return jsonify({
            'success': True,
            'inventory': item.to_dict()
        }), 200
    except Exception as e:
        logger.error(f'Error getting inventory item: {str(e)}')
        return jsonify({'error': 'Failed to get inventory item'}), 500


@inventory_bp.route('/inventory/<item_id>', methods=['PUT'])
@cross_origin()
@token_required
def update_inventory(item_id):
    """Update an inventory item."""
    try:
        user_id = request.user_id
        item = Inventory.query.filter_by(id=item_id, user_id=user_id).first()
        
        if not item:
            return jsonify({'error': 'Inventory item not found'}), 404
        
        data = request.get_json()
        
        # Update fields if provided
        if 'name' in data:
            item.name = data['name']
        if 'category' in data:
            item.category = data['category']
        if 'sku' in data:
            item.sku = data['sku']
        if 'purchase_date' in data:
            item.purchase_date = data['purchase_date']
        if 'purchase_price' in data:
            item.purchase_price = data['purchase_price']
        if 'addition_date' in data:
            ad = data.get('addition_date')
            if ad:
                try:
                    if isinstance(ad, str):
                        item.addition_date = datetime.fromisoformat(ad).date()
                    elif isinstance(ad, datetime):
                        item.addition_date = ad.date()
                    else:
                        item.addition_date = ad
                except Exception:
                    item.addition_date = None
            else:
                item.addition_date = None
        if 'lifetime_days' in data:
            try:
                item.lifetime_days = int(data.get('lifetime_days')) if data.get('lifetime_days') is not None else None
            except Exception:
                item.lifetime_days = None

        # auto-calculate disposal_date when we have addition_date and lifetime_days
        try:
            if item.addition_date and item.lifetime_days:
                ad = item.addition_date
                if isinstance(ad, datetime):
                    ad = ad.date()
                item.disposal_date = ad + timedelta(days=int(item.lifetime_days))
            else:
                # if explicit disposal_date provided as string, parse it
                if 'disposal_date' in data and data.get('disposal_date'):
                    dd = data.get('disposal_date')
                    try:
                        if isinstance(dd, str):
                            item.disposal_date = datetime.fromisoformat(dd).date()
                        elif isinstance(dd, datetime):
                            item.disposal_date = dd.date()
                        else:
                            item.disposal_date = dd
                    except Exception:
                        item.disposal_date = None
        except Exception:
            pass
        # Do not allow manual status assignment for inventory; status is computed from kit membership and disposal_date
        if 'location' in data:
            item.location = data['location']
        if 'notes' in data:
            item.notes = data['notes']
        
        db.session.commit()
        
        logger.info(f'Inventory item updated: {item.id}')
        return jsonify({
            'success': True,
            'message': 'Inventory item updated successfully',
            'inventory': item.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error updating inventory: {str(e)}')
        return jsonify({'error': 'Failed to update inventory'}), 500


@inventory_bp.route('/inventory/<item_id>', methods=['DELETE'])
@cross_origin()
@token_required
def delete_inventory(item_id):
    """Delete an inventory item."""
    try:
        user_id = request.user_id
        item = Inventory.query.filter_by(id=item_id, user_id=user_id).first()
        
        if not item:
            return jsonify({'error': 'Inventory item not found'}), 404
        
        # Remove associations to kits but do not delete kits themselves
        from app.models import KitInventory
        db.session.query(KitInventory).filter(KitInventory.inventory_id == item.id).delete(synchronize_session=False)
        db.session.delete(item)
        db.session.commit()
        
        logger.info(f'Inventory item deleted: {item.id}')
        return jsonify({
            'success': True,
            'message': 'Inventory item deleted successfully'
        }), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error deleting inventory: {str(e)}')
        return jsonify({'error': 'Failed to delete inventory'}), 500


@inventory_bp.route('/inventory/batch/delete', methods=['POST'])
@cross_origin()
@token_required
def delete_inventory_batch():
    """Delete multiple inventory items."""
    try:
        user_id = request.user_id
        data = request.get_json()
        
        if not data or not isinstance(data.get('ids'), list):
            return jsonify({'error': 'Array of ids is required'}), 400
        
        ids = data.get('ids')
        
        # Remove associations and delete items without deleting kits
        from app.models import KitInventory
        for iid in ids:
            # only operate on items belonging to this user
            inv = Inventory.query.filter_by(id=iid, user_id=user_id).first()
            if inv:
                db.session.query(KitInventory).filter(KitInventory.inventory_id == inv.id).delete(synchronize_session=False)
                db.session.delete(inv)
        db.session.flush()
        deleted_count = len(ids)
        
        db.session.commit()
        
        logger.info(f'Deleted {deleted_count} inventory items')
        return jsonify({
            'success': True,
            'message': f'Successfully deleted {deleted_count} items',
            'deleted_count': deleted_count
        }), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error deleting inventory batch: {str(e)}')
        return jsonify({'error': 'Failed to delete inventory'}), 500
