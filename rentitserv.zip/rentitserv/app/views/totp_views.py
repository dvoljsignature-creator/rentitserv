"""
TOTP API endpoints.
Handles two-factor authentication setup and verification.
"""
from flask import Blueprint, request, jsonify, current_app, make_response
from app.services import TOTPService, AuthService, token_required
from app.models import User
from logging_config import get_logger

logger = get_logger(__name__)

totp_bp = Blueprint('totp', __name__, url_prefix='/api/totp')


@totp_bp.route('/setup/email', methods=['POST'])
@token_required
def setup_email_totp():
    """
    Setup email-based TOTP.
    
    Returns:
        - 200: Email TOTP code sent
        - 500: Setup failed
    """
    try:
        from flask import current_app
        success, result = TOTPService.setup_email_totp(request.user_id)

        if not success:
            return jsonify({'error': result}), 400

        response = {
            'message': 'TOTP code sent to your email',
            'code_sent': True,
        }
        
        # In development mode, include the code for testing
        if current_app.debug or current_app.config.get('TESTING', False):
            response['code'] = result
            response['debug_note'] = 'Code included for development/testing purposes only'
        
        return jsonify(response), 200
        
    except Exception as e:
        logger.error(f"Email TOTP setup endpoint error: {str(e)}")
        return jsonify({'error': 'Setup failed'}), 500


@totp_bp.route('/verify/email', methods=['POST'])
@token_required
def verify_email_totp():
    """
    Verify email-based TOTP code.
    
    Expected JSON:
    {
        "code": "123456"
    }
    
    Returns:
        - 200: TOTP verified successfully
        - 400: Invalid code
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('code'):
            return jsonify({'error': 'Code required'}), 400
        
        success, msg = TOTPService.verify_email_totp(request.user_id, data['code'])
        
        if not success:
            return jsonify({'error': msg}), 400
        
        # Generate tokens after successful TOTP verification
        user = User.query.get(request.user_id)
        tokens = AuthService.generate_tokens(user)

        # Return tokens and set access token cookie
        payload = {'message': msg, 'tokens': tokens}
        response = make_response(jsonify(payload), 200)
        try:
            exp_delta = current_app.config.get('JWT_ACCESS_TOKEN_EXPIRES')
            if hasattr(exp_delta, 'total_seconds'):
                max_age = int(exp_delta.total_seconds())
            else:
                max_age = None

            cookie_name = current_app.config.get('ACCESS_TOKEN_COOKIE_NAME', 'rentit_access_token')
            default_secure = not bool(current_app.debug)
            secure = bool(current_app.config.get('SESSION_COOKIE_SECURE', default_secure))
            samesite = current_app.config.get('SESSION_COOKIE_SAMESITE', 'Lax')
            response.set_cookie(cookie_name, tokens.get('access_token'), max_age=max_age, secure=secure, httponly=True, samesite=samesite, path='/')
        except Exception:
            pass

        return response
        
    except Exception as e:
        logger.error(f"Email TOTP verify endpoint error: {str(e)}")
        return jsonify({'error': 'Verification failed'}), 500


@totp_bp.route('/setup/app', methods=['POST'])
@token_required
def setup_app_totp():
    """
    Setup authenticator app TOTP.
    
    Returns:
        - 200: Setup data (secret, QR code, backup codes)
        - 500: Setup failed
    """
    try:
        success, result = TOTPService.setup_app_totp(request.user_id)
        
        if not success:
            return jsonify({'error': result}), 400
        
        return jsonify({
            'message': 'Authenticator app setup',
            'setup_data': result,
        }), 200
        
    except Exception as e:
        logger.error(f"App TOTP setup endpoint error: {str(e)}")
        return jsonify({'error': 'Setup failed'}), 500


@totp_bp.route('/verify/app', methods=['POST'])
@token_required
def verify_app_totp():
    """
    Verify authenticator app TOTP code.
    
    Expected JSON:
    {
        "code": "123456"
    }
    
    Returns:
        - 200: TOTP verified successfully
        - 400: Invalid code
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('code'):
            return jsonify({'error': 'Code required'}), 400
        
        success, msg = TOTPService.verify_app_totp(request.user_id, data['code'])
        
        if not success:
            return jsonify({'error': msg}), 400
        
        # Generate tokens after successful TOTP verification
        user = User.query.get(request.user_id)
        tokens = AuthService.generate_tokens(user)

        payload = {'message': msg, 'tokens': tokens}
        response = make_response(jsonify(payload), 200)
        try:
            exp_delta = current_app.config.get('JWT_ACCESS_TOKEN_EXPIRES')
            if hasattr(exp_delta, 'total_seconds'):
                max_age = int(exp_delta.total_seconds())
            else:
                max_age = None

            cookie_name = current_app.config.get('ACCESS_TOKEN_COOKIE_NAME', 'rentit_access_token')
            secure = bool(current_app.config.get('SESSION_COOKIE_SECURE', True))
            samesite = current_app.config.get('SESSION_COOKIE_SAMESITE', 'Lax')
            response.set_cookie(cookie_name, tokens.get('access_token'), max_age=max_age, secure=secure, httponly=True, samesite=samesite, path='/')
        except Exception:
            pass

        return response
        
    except Exception as e:
        logger.error(f"App TOTP verify endpoint error: {str(e)}")
        return jsonify({'error': 'Verification failed'}), 500


@totp_bp.route('/verify/login', methods=['POST'])
def verify_login_totp():
    """
    Verify TOTP during login.
    
    Expected JSON:
    {
        "user_id": "user_uuid",
        "code": "123456"
    }
    
    Returns:
        - 200: TOTP verified, tokens generated
        - 400: Invalid code
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('user_id') or not data.get('code'):
            return jsonify({'error': 'User ID and code required'}), 400
        
        success, msg = TOTPService.verify_login_totp(data['user_id'], data['code'])
        
        if not success:
            return jsonify({'error': msg}), 400
        
        # Generate tokens
        user = User.query.get(data['user_id'])
        tokens = AuthService.generate_tokens(user)

        payload = {'message': 'Login successful', 'tokens': tokens}
        response = make_response(jsonify(payload), 200)
        try:
            exp_delta = current_app.config.get('JWT_ACCESS_TOKEN_EXPIRES')
            if hasattr(exp_delta, 'total_seconds'):
                max_age = int(exp_delta.total_seconds())
            else:
                max_age = None

            cookie_name = current_app.config.get('ACCESS_TOKEN_COOKIE_NAME', 'rentit_access_token')
            secure = bool(current_app.config.get('SESSION_COOKIE_SECURE', True))
            samesite = current_app.config.get('SESSION_COOKIE_SAMESITE', 'Lax')
            response.set_cookie(cookie_name, tokens.get('access_token'), max_age=max_age, secure=secure, httponly=True, samesite=samesite, path='/')
        except Exception:
            pass

        return response
        
    except Exception as e:
        logger.error(f"Login TOTP verify endpoint error: {str(e)}")
        return jsonify({'error': 'Verification failed'}), 500


@totp_bp.route('/disable', methods=['POST'])
@token_required
def disable_totp():
    """
    Disable TOTP for user.
    
    Returns:
        - 200: TOTP disabled
        - 500: Disable failed
    """
    try:
        success, msg = TOTPService.disable_totp(request.user_id)
        
        if not success:
            return jsonify({'error': msg}), 400
        
        return jsonify({'message': msg}), 200
        
    except Exception as e:
        logger.error(f"TOTP disable endpoint error: {str(e)}")
        return jsonify({'error': 'Disable failed'}), 500

@totp_bp.route('/resend-login', methods=['POST'])
def resend_login_email():
    """
    Resend email TOTP code during login flow (unauthenticated).

    Expected JSON: { "user_id": "..." }

    Returns 200 and message on success, 400 on error.
    """
    try:
        data = request.get_json()
        if not data or not data.get('user_id'):
            return jsonify({'error': 'User ID required'}), 400

        user_id = data.get('user_id')

        # Ensure user exists
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 400

        # Only attempt to send email code if email TOTP is possible for this user
        totp_settings = user.totp_settings
        if not totp_settings or (not getattr(totp_settings, 'email_totp_secret', None) and getattr(totp_settings, 'totp_type', None) not in ('email', 'both')):
            # Still allow sending a code to enable email-based TOTP for login
            # but warn if user clearly does not have email TOTP configured
            logger.info(f"Resend requested but user may not have email TOTP configured: {user.email}")

        success, result = TOTPService.setup_email_totp(user_id)

        if not success:
            return jsonify({'error': result}), 400

        resp = {'message': 'TOTP code sent'}
        # In debug/testing include code
        try:
            if current_app.debug or current_app.config.get('TESTING', False):
                resp['code'] = result
        except Exception:
            pass

        return jsonify(resp), 200

    except Exception as e:
        logger.exception(f'Resend login email endpoint error: {str(e)}')
        return jsonify({'error': 'Internal server error'}), 500


# Debug endpoint: generate a QR code PNG for a test email or provided email
@totp_bp.route('/debug/qrcode', methods=['GET'])
def debug_qrcode():
    """Return a QR code PNG for a test provisioning URI.

    Query params:
      - email (optional): email to embed in provisioning URI (default: test@example.com)

    This endpoint is intended for local development and debugging only.
    """
    from flask import Response, request
    from app.services.totp_service import TOTPService

    email = request.args.get('email', 'test@example.com')

    try:
        secret = TOTPService.generate_secret()
        provisioning_uri = TOTPService.get_totp_provisioning_uri(secret, email)
        data_uri = TOTPService.get_qr_code(provisioning_uri)

        if not data_uri:
            logger.error('Debug QR: get_qr_code returned None')
            return jsonify({'error': 'QR generation failed'}), 500

        # data_uri is like 'data:image/png;base64,...'
        prefix = 'base64,'
        idx = data_uri.find(prefix)
        if idx == -1:
            logger.error('Debug QR: unexpected data URI format')
            return jsonify({'error': 'Unexpected QR format'}), 500

        b64 = data_uri[idx + len(prefix):]
        import base64
        img_bytes = base64.b64decode(b64)

        resp = Response(img_bytes, mimetype='image/png')
        resp.headers['Content-Disposition'] = 'inline; filename="qrcode.png"'
        return resp

    except Exception as e:
        logger.exception(f'Debug QR endpoint error: {str(e)}')
        return jsonify({'error': 'Internal error generating QR', 'detail': str(e)}), 500
