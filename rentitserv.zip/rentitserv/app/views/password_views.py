"""
Password reset API endpoints.
"""
from flask import Blueprint, request, jsonify
from app.services import PasswordResetService
from logging_config import get_logger

logger = get_logger(__name__)

password_bp = Blueprint('password', __name__, url_prefix='/api/password')


@password_bp.route('/forgot', methods=['POST'])
def forgot_password():
    """
    Request password reset.
    
    Expected JSON:
    {
        "email": "user@example.com"
    }
    
    Returns:
        - 200: Reset link sent (or generic message for security)
        - 400: Invalid input
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('email'):
            return jsonify({'error': 'Email required'}), 400
        
        success, msg = PasswordResetService.request_password_reset(data['email'])
        
        # Always return success message for security
        return jsonify({'message': 'If email exists, reset link will be sent'}), 200
        
    except Exception as e:
        logger.error(f"Forgot password endpoint error: {str(e)}")
        return jsonify({'error': 'Request failed'}), 500


@password_bp.route('/reset', methods=['POST'])
def reset_password():
    """
    Reset password using reset token.
    
    Expected JSON:
    {
        "token": "reset_token",
        "new_password": "NewPassword123!"
    }
    
    Returns:
        - 200: Password reset successfully
        - 400: Invalid token or password
    """
    try:
        data = request.get_json()
        
        if not data or not data.get('token') or not data.get('new_password'):
            return jsonify({'error': 'Token and new password required'}), 400
        
        success, msg = PasswordResetService.reset_password(data['token'], data['new_password'])
        
        if not success:
            return jsonify({'error': msg}), 400
        
        return jsonify({'message': msg}), 200
        
    except Exception as e:
        logger.error(f"Reset password endpoint error: {str(e)}")
        return jsonify({'error': 'Reset failed'}), 500
