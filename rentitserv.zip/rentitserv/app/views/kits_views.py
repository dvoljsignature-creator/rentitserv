"""
Kits management endpoints.
"""
from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from app.models import db, Kit, KitInventory, Inventory
from app.services.auth_service import token_required
import logging

kits_bp = Blueprint('kits', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)


@kits_bp.route('/kits', methods=['GET'])
@cross_origin()
@token_required
def get_kits():
    """Get all kits for the current user."""
    try:
        user_id = request.user_id
        kits = Kit.query.filter_by(user_id=user_id).order_by(Kit.sequence_number).all()
        
        return jsonify({
            'success': True,
            'kits': [kit.to_dict(include_inventories=True) for kit in kits]
        }), 200
    except Exception as e:
        logger.error(f'Error getting kits: {str(e)}')
        return jsonify({'error': 'Failed to get kits'}), 500


@kits_bp.route('/kits', methods=['POST'])
@cross_origin()
@token_required
def create_kit():
    """Create a new kit."""
    try:
        user_id = request.user_id
        data = request.get_json()
        
        if not data or not data.get('name'):
            return jsonify({'error': 'Kit name is required'}), 400
        
        # Get the next sequence number for this user
        last_kit = Kit.query.filter_by(user_id=user_id).order_by(Kit.sequence_number.desc()).first()
        next_sequence = (last_kit.sequence_number + 1) if last_kit else 1
        
        # Create new kit
        new_kit = Kit(
            user_id=user_id,
            sequence_number=next_sequence,
            name=data.get('name'),
            description=data.get('description'),
            status=(data.get('status') if data.get('status') in ('active','waiting','inactive') else 'active'),
            created_date=data.get('created_date'),
            location=data.get('location'),
            notes=data.get('notes')
        )
        
        db.session.add(new_kit)
        db.session.commit()
        
        # Add inventory items if provided
        inventory_ids = data.get('inventory_ids', [])
        for inventory_id in inventory_ids:
            # Verify inventory belongs to user
            inventory = Inventory.query.filter_by(id=inventory_id, user_id=user_id).first()
            if inventory:
                kit_inv = KitInventory(kit_id=new_kit.id, inventory_id=inventory_id)
                db.session.add(kit_inv)
        
        db.session.commit()
        
        logger.info(f'Kit created: {new_kit.id}')
        return jsonify({
            'success': True,
            'message': 'Kit created successfully',
            'kit': new_kit.to_dict(include_inventories=True)
        }), 201
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error creating kit: {str(e)}')
        return jsonify({'error': 'Failed to create kit'}), 500


@kits_bp.route('/kits/<kit_id>', methods=['GET'])
@cross_origin()
@token_required
def get_kit(kit_id):
    """Get a specific kit."""
    try:
        user_id = request.user_id
        kit = Kit.query.filter_by(id=kit_id, user_id=user_id).first()
        
        if not kit:
            return jsonify({'error': 'Kit not found'}), 404
        
        return jsonify({
            'success': True,
            'kit': kit.to_dict(include_inventories=True)
        }), 200
    except Exception as e:
        logger.error(f'Error getting kit: {str(e)}')
        return jsonify({'error': 'Failed to get kit'}), 500


@kits_bp.route('/kits/<kit_id>', methods=['PUT'])
@cross_origin()
@token_required
def update_kit(kit_id):
    """Update a kit."""
    try:
        user_id = request.user_id
        kit = Kit.query.filter_by(id=kit_id, user_id=user_id).first()
        
        if not kit:
            return jsonify({'error': 'Kit not found'}), 404
        
        data = request.get_json()
        
        # Update fields if provided
        if 'name' in data:
            kit.name = data['name']
        if 'description' in data:
            kit.description = data['description']
        if 'status' in data:
            # prevent 'end_of_life' being set on kits; coerce to allowed values
            kit.status = data.get('status') if data.get('status') in ('active','waiting','inactive') else kit.status
        if 'created_date' in data:
            kit.created_date = data['created_date']
        if 'location' in data:
            kit.location = data['location']
        if 'notes' in data:
            kit.notes = data['notes']
        
        # Update inventory items if provided
        if 'inventory_ids' in data:
            # Clear existing associations
            KitInventory.query.filter_by(kit_id=kit_id).delete()
            
            # Add new inventory items
            inventory_ids = data.get('inventory_ids', [])
            for inventory_id in inventory_ids:
                # Verify inventory belongs to user
                inventory = Inventory.query.filter_by(id=inventory_id, user_id=user_id).first()
                if inventory:
                    kit_inv = KitInventory(kit_id=kit_id, inventory_id=inventory_id)
                    db.session.add(kit_inv)
        
        db.session.commit()
        
        logger.info(f'Kit updated: {kit.id}')
        return jsonify({
            'success': True,
            'message': 'Kit updated successfully',
            'kit': kit.to_dict(include_inventories=True)
        }), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error updating kit: {str(e)}')
        return jsonify({'error': 'Failed to update kit'}), 500


@kits_bp.route('/kits/<kit_id>', methods=['DELETE'])
@cross_origin()
@token_required
def delete_kit(kit_id):
    """Delete a kit."""
    try:
        user_id = request.user_id
        kit = Kit.query.filter_by(id=kit_id, user_id=user_id).first()
        
        if not kit:
            return jsonify({'error': 'Kit not found'}), 404
        
        db.session.delete(kit)
        db.session.commit()
        
        logger.info(f'Kit deleted: {kit.id}')
        return jsonify({
            'success': True,
            'message': 'Kit deleted successfully'
        }), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error deleting kit: {str(e)}')
        return jsonify({'error': 'Failed to delete kit'}), 500


@kits_bp.route('/kits/batch/delete', methods=['POST'])
@cross_origin()
@token_required
def delete_kits_batch():
    """Delete multiple kits."""
    try:
        user_id = request.user_id
        data = request.get_json()
        
        if not data or not isinstance(data.get('ids'), list):
            return jsonify({'error': 'Array of ids is required'}), 400
        
        ids = data.get('ids')
        
        # Delete kits
        deleted_count = Kit.query.filter(
            Kit.id.in_(ids),
            Kit.user_id == user_id
        ).delete()
        
        db.session.commit()
        
        logger.info(f'Deleted {deleted_count} kits')
        return jsonify({
            'success': True,
            'message': f'Successfully deleted {deleted_count} kits',
            'deleted_count': deleted_count
        }), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error deleting kits batch: {str(e)}')
        return jsonify({'error': 'Failed to delete kits'}), 500
