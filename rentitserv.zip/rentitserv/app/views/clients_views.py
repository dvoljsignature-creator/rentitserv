"""
Clients management endpoints.
"""
from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
from app.models import db, Client
from app.services.auth_service import token_required
import logging

clients_bp = Blueprint('clients', __name__, url_prefix='/api')
logger = logging.getLogger(__name__)


@clients_bp.route('/clients', methods=['GET'])
@cross_origin()
@token_required
def get_clients():
    """Get all clients for the current user."""
    try:
        user_id = request.user_id
        clients = Client.query.filter_by(user_id=user_id, is_active=True).all()
        
        return jsonify({
            'success': True,
            'clients': [client.to_dict() for client in clients]
        }), 200
    except Exception as e:
        logger.error(f'Error getting clients: {str(e)}')
        return jsonify({'error': 'Failed to get clients'}), 500


@clients_bp.route('/clients', methods=['POST'])
@cross_origin()
@token_required
def create_client():
    """Create a new client."""
    try:
        user_id = request.user_id
        data = request.get_json()
        
        if not data or not data.get('name'):
            return jsonify({'error': 'Client name is required'}), 400
        
        # Get the next sequence number for this user
        last_client = Client.query.filter_by(user_id=user_id, is_active=True).order_by(Client.sequence_number.desc()).first()
        next_sequence = (last_client.sequence_number + 1) if last_client else 1
        
        # Create new client
        new_client = Client(
            user_id=user_id,
            sequence_number=next_sequence,
            name=data.get('name'),
            email=data.get('email'),
            phone=data.get('phone'),
            address=data.get('address'),
            company=data.get('company'),
            notes=data.get('notes')
        )
        
        db.session.add(new_client)
        db.session.commit()
        
        logger.info(f'Client created: {new_client.id}')
        return jsonify({
            'success': True,
            'message': 'Client created successfully',
            'client': new_client.to_dict()
        }), 201
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error creating client: {str(e)}')
        return jsonify({'error': 'Failed to create client'}), 500


@clients_bp.route('/clients/<client_id>', methods=['GET'])
@cross_origin()
@token_required
def get_client(client_id):
    """Get a specific client."""
    try:
        user_id = request.user_id
        client = Client.query.filter_by(id=client_id, user_id=user_id).first()
        
        if not client:
            return jsonify({'error': 'Client not found'}), 404
        
        return jsonify({
            'success': True,
            'client': client.to_dict()
        }), 200
    except Exception as e:
        logger.error(f'Error getting client: {str(e)}')
        return jsonify({'error': 'Failed to get client'}), 500


@clients_bp.route('/clients/<client_id>', methods=['PUT'])
@cross_origin()
@token_required
def update_client(client_id):
    """Update a client."""
    try:
        user_id = request.user_id
        client = Client.query.filter_by(id=client_id, user_id=user_id).first()
        
        if not client:
            return jsonify({'error': 'Client not found'}), 404
        
        data = request.get_json()
        
        # Update fields if provided
        if 'name' in data:
            client.name = data['name']
        if 'email' in data:
            client.email = data['email']
        if 'phone' in data:
            client.phone = data['phone']
        if 'address' in data:
            client.address = data['address']
        if 'company' in data:
            client.company = data['company']
        if 'notes' in data:
            client.notes = data['notes']
        
        db.session.commit()
        
        logger.info(f'Client updated: {client.id}')
        return jsonify({
            'success': True,
            'message': 'Client updated successfully',
            'client': client.to_dict()
        }), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error updating client: {str(e)}')
        return jsonify({'error': 'Failed to update client'}), 500


@clients_bp.route('/clients/<client_id>', methods=['DELETE'])
@cross_origin()
@token_required
def delete_client(client_id):
    """Delete a client (soft delete)."""
    try:
        user_id = request.user_id
        client = Client.query.filter_by(id=client_id, user_id=user_id).first()
        
        if not client:
            return jsonify({'error': 'Client not found'}), 404
        
        # Soft delete
        client.is_active = False
        db.session.commit()
        
        logger.info(f'Client deleted: {client.id}')
        return jsonify({
            'success': True,
            'message': 'Client deleted successfully'
        }), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error deleting client: {str(e)}')
        return jsonify({'error': 'Failed to delete client'}), 500


@clients_bp.route('/clients/batch/delete', methods=['POST'])
@cross_origin()
@token_required
def delete_clients_batch():
    """Soft-delete multiple clients for the current user."""
    try:
        user_id = request.user_id
        data = request.get_json()

        if not data or not isinstance(data.get('ids'), list):
            return jsonify({'error': 'Array of ids is required'}), 400

        ids = data.get('ids')

        # Soft-delete matching clients
        from sqlalchemy import and_
        updated = Client.query.filter(
            Client.id.in_(ids),
            Client.user_id == user_id
        ).update({ 'is_active': False }, synchronize_session=False)

        db.session.commit()

        logger.info(f'Deleted {updated} clients')
        return jsonify({
            'success': True,
            'message': f'Successfully deleted {updated} clients',
            'deleted_count': updated
        }), 200
    except Exception as e:
        db.session.rollback()
        logger.error(f'Error deleting clients batch: {str(e)}')
        return jsonify({'error': 'Failed to delete clients'}), 500
