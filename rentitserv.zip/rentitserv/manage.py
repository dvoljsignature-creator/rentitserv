"""
Management and utility commands for RentIT application.

Usage:
    python manage.py init-db       - Initialize database
    python manage.py drop-db       - Drop all tables
    python manage.py reset-db      - Reset database
    python manage.py create-user   - Create a test user
    python manage.py shell         - Interactive shell
"""

import sys
from app import create_app
from app.models import db, User
from app.services import AuthService


def init_db():
    """Initialize database."""
    app = create_app()
    with app.app_context():
        db.create_all()
        print("✓ Database initialized successfully")


def drop_db():
    """Drop all tables."""
    app = create_app()
    with app.app_context():
        db.drop_all()
        print("✓ Database dropped successfully")


def reset_db():
    """Reset database."""
    app = create_app()
    with app.app_context():
        db.drop_all()
        db.create_all()
        print("✓ Database reset successfully")


def create_user():
    """Create a test user."""
    app = create_app()
    with app.app_context():
        email = input("Email: ")
        username = input("Username: ")
        password = input("Password: ")
        first_name = input("First name (optional): ")
        last_name = input("Last name (optional): ")
        
        success, result = AuthService.register(
            email=email,
            username=username,
            password=password,
            first_name=first_name,
            last_name=last_name
        )
        
        if success:
            user = result
            user.is_verified = True  # Auto-verify for test user
            db.session.commit()
            print(f"✓ User created successfully: {email}")
        else:
            print(f"✗ Error: {result}")


def shell():
    """Interactive Python shell with app context."""
    app = create_app()
    with app.app_context():
        from app.models import User, TOTPSettings, RefreshToken
        from app.services import AuthService, TOTPService
        
        context = {
            'app': app,
            'db': db,
            'User': User,
            'TOTPSettings': TOTPSettings,
            'RefreshToken': RefreshToken,
            'AuthService': AuthService,
            'TOTPService': TOTPService,
        }
        
        print("Python shell with app context")
        print("Available objects: app, db, User, TOTPSettings, RefreshToken, AuthService, TOTPService")
        
        import code
        code.interact(local=context)


def main():
    """Main entry point."""
    if len(sys.argv) < 2:
        print(__doc__)
        return
    
    command = sys.argv[1]
    
    commands = {
        'init-db': init_db,
        'drop-db': drop_db,
        'reset-db': reset_db,
        'create-user': create_user,
        'shell': shell,
    }
    
    if command in commands:
        commands[command]()
    else:
        print(f"✗ Unknown command: {command}")
        print(__doc__)


if __name__ == "__main__":
    main()
