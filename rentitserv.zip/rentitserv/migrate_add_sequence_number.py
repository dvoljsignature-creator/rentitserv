#!/usr/bin/env python
"""
Migration script to add sequence_number column to clients table.
This script will:
1. Add the sequence_number column to existing clients table
2. Assign sequence numbers based on created_at timestamp per user
"""

import os
import sys
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import create_app
from app.models import db, Client, User

def migrate():
    """Run the migration."""
    app = create_app()
    
    with app.app_context():
        try:
            # Check if sequence_number column exists
            inspector = db.inspect(db.engine)
            columns = [col['name'] for col in inspector.get_columns('clients')]
            
            if 'sequence_number' in columns:
                print("Column 'sequence_number' already exists. Skipping migration.")
                return
            
            print("Adding 'sequence_number' column to clients table...")
            
            # Add the column
            with db.engine.begin() as connection:
                connection.execute(db.text(
                    'ALTER TABLE clients ADD COLUMN sequence_number INTEGER'
                ))
            
            print("Column added successfully.")
            
            # Now assign sequence numbers per user
            print("Assigning sequence numbers...")
            
            users = User.query.all()
            for user in users:
                clients = Client.query.filter_by(user_id=user.id).order_by(Client.created_at).all()
                for idx, client in enumerate(clients, 1):
                    client.sequence_number = idx
                    print(f"  User {user.username}: Client {client.name} -> #{idx}")
            
            db.session.commit()
            print("Migration completed successfully!")
            
        except Exception as e:
            print(f"Error during migration: {str(e)}")
            db.session.rollback()
            raise

if __name__ == '__main__':
    migrate()
