import sys
p = r'c:\Users\Admin\Documents\rentit\config.py'
with open(p, 'rb') as f:
    data = f.read()
print('FILE PATH:', p)
print('LENGTH:', len(data))
print('FIRST 200 BYTES:', data[:200])
text = data.decode('utf-8', errors='replace')
for i, l in enumerate(text.splitlines(), 1):
    if i <= 30:
        print(f"{i}: {repr(l)}")
    if i == 13:
        print('\nLINE 13 CHAR CODES:')
        for idx, ch in enumerate(l):
            print(idx, ch, hex(ord(ch)))
        break
