
import os
import shutil
import sys
from datetime import datetime

# Ensure local project package is imported instead of any globally installed `app` package.
# Insert project root at the front of sys.path before importing application modules.
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from typing import Optional

# Import application objects lazily inside `main()` to avoid accidental import of the
# wrong `app` package when the script is executed without project context.
create_app = None
db = None
User = None

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
DB_FILE = os.path.join(PROJECT_ROOT, 'rentit.db')


def is_production(app):
    """Heuristic check whether app is running in production-like mode.

    We treat the environment as production if:
    - `FLASK_ENV` is set to 'production', or
    - `SESSION_COOKIE_SECURE` is True, OR
    - neither `DEBUG` nor `TESTING` are True.
    """
    env = os.getenv('FLASK_ENV', '').lower()
    if env == 'production':
        return True

    if app.config.get('SESSION_COOKIE_SECURE'):
        return True

    if not app.config.get('DEBUG', False) and not app.config.get('TESTING', False):
        # Very likely production/staging
        return True

    return False


def backup_sqlite(db_path: str) -> str:
    """Create a timestamped copy of the sqlite DB if it exists and return its path."""
    if not os.path.exists(db_path):
        return ''

    ts = datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
    backup_path = f"{db_path}.backup.{ts}"
    try:
        shutil.copy2(db_path, backup_path)
        return backup_path
    except Exception:
        return ''


def main():
    print('Delete All Users (debug script)')
    print('IMPORTANT: This will permanently delete user records from the database.')
    print('Always backup your DB before running this script.')
    print()

    # Import application factory and models here (after sys.path is set)
    global create_app, db, User
    from app import create_app as _create_app
    from app.models import db as _db, User as _User
    create_app = _create_app
    db = _db
    User = _User

    app = create_app()

    with app.app_context():
        if is_production(app) and os.getenv('FORCE_DELETE_ALL_USERS') != '1':
            print('\nRefusing to run in production-like environment.')
            print("If you really want to run this in production, set environment variable FORCE_DELETE_ALL_USERS=1 and re-run.")
            sys.exit(1)

        # Offer to back up sqlite DB if present
        if os.path.exists(DB_FILE):
            print(f"Detected sqlite DB at {DB_FILE}")
            backup = input('Create a backup copy before deleting? (Y/n): ').strip().lower() or 'y'
            if backup == 'y':
                backup_path = backup_sqlite(DB_FILE)
                if backup_path:
                    print(f'Backup created at: {backup_path}')
                else:
                    print('Backup failed or not possible; proceeding without file backup.')

        total = User.query.count()
        print(f'Found {total} user(s) in the database.')

        if total == 0:
            print('No users to delete. Exiting.')
            return

        print('\nType the exact phrase "DAU" to confirm and proceed.')
        confirm = input('> ').strip()
        if confirm != 'DAU':
            print('Confirmation did not match. Aborting.')
            return

        # Final explicit confirmation
        final = input('Final confirmation. Type YES to permanently delete all users: ').strip()
        if final != 'YES':
            print('Final confirmation failed. Aborting.')
            return

        # Perform deletion
        try:
            users = User.query.all()
            for u in users:
                db.session.delete(u)

            db.session.commit()
            print(f'Deleted {total} user(s).')

        except Exception as e:
            db.session.rollback()
            print('Error deleting users:', str(e))
            sys.exit(1)


if __name__ == '__main__':
    main()
