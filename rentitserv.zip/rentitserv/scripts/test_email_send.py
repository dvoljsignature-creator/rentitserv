#!/usr/bin/env python3
"""
Test email sending script.
Allows sending test emails to verify SMTP configuration.
"""
import os
import sys
from pathlib import Path

# Add parent directory to path to import app modules
sys.path.insert(0, str(Path(__file__).parent.parent))

from flask import Flask
from app.services.email_service import EmailService
from config import get_config


def main():
    """Send a test email."""
    # Get recipient email
    recipient = input("Enter recipient email address: ").strip()
    
    if not recipient:
        print("Error: Email address cannot be empty")
        return
    
    # Create Flask app context
    app = Flask(__name__)
    app.config.from_object(get_config())
    
    with app.app_context():
        # Check if password is configured
        if not app.config.get('MAIL_PASSWORD'):
            print("ERROR: MAIL_PASSWORD is not set!")
            print("Please set it via:")
            print("  1. Environment variable: set MAIL_PASSWORD=your_app_password")
            print("  2. Or create .env file with: MAIL_PASSWORD=your_app_password")
            print("  3. Or update config.py with default value")
            return
        
        print(f"\nSending test email to: {recipient}")
        print(f"From: {app.config.get('MAIL_DEFAULT_SENDER')}")
        print(f"SMTP Server: {app.config.get('MAIL_SERVER')}:{app.config.get('MAIL_PORT')}")
        print("-" * 50)
        
        subject = "RentIT Test Email"
        body = """
This is a test email from RentIT application.

If you received this email, your SMTP configuration is working correctly!

Test Code: 123456
        """
        
        html = """
<html>
<body>
    <h2>RentIT Test Email</h2>
    <p>This is a test email from RentIT application.</p>
    <p>If you received this email, your SMTP configuration is working correctly!</p>
    <p><strong>Test Code: 123456</strong></p>
</body>
</html>
        """
        
        success, message = EmailService.send_email(recipient, subject, body, html)
        
        if success:
            print(f"\n✓ SUCCESS: {message}")
        else:
            print(f"\n✗ FAILED: {message}")
            print("\nTroubleshooting:")
            print("1. Check that MAIL_PASSWORD is set correctly (use App Password, not regular password)")
            print("2. For Gmail, get App Password from: https://myaccount.google.com/apppasswords")
            print("3. Ensure 2FA is enabled on your Google account")
            print("4. Check internet connection and firewall settings")


if __name__ == '__main__':
    main()
