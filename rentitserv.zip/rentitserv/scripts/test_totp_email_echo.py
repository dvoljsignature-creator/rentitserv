from app import create_app
from app.services.email_service import EmailService

app = create_app()

with app.app_context():
    # Simulate sending a TOTP email; this will attempt to send but will always
    # echo the generated code to the terminal before sending.
    success, msg = EmailService.send_totp_email('dev-recipient@example.com', '123456')
    print('send_totp_email returned:', success, msg)
