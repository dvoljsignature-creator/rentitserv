from app import create_app
from app.services.totp_service import TOTPService

app = create_app()
with app.app_context():
    secret = TOTPService.generate_secret()
    uri = TOTPService.get_totp_provisioning_uri(secret, 'test@example.com', issuer='RentIT')
    print('Provisioning URI:', uri)
    img = TOTPService.get_qr_code(uri)
    print('QR result type:', type(img))
    print('QR length:', len(img) if img else None)