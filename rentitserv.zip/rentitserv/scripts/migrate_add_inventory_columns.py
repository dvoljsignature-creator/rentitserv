# Small migration helper: add missing inventory columns in SQLite
# Usage: python scripts\migrate_add_inventory_columns.py
import os
import sys
from sqlalchemy import create_engine, text

# Ensure project root is on sys.path so we can import config
HERE = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(HERE, '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from config import get_config

cfg = get_config()
db_uri = cfg.SQLALCHEMY_DATABASE_URI
engine = create_engine(db_uri)

# Helper to try a different sqlite file path (useful when app stores DB in 'instance/')
def try_connect_sqlite_path(path):
    if not os.path.exists(path):
        return None
    uri = f"sqlite:///{os.path.abspath(path)}"
    try:
        return create_engine(uri)
    except Exception:
        return None

required_columns = {
    'addition_date': 'DATE',
    'lifetime_days': 'INTEGER',
    'disposal_date': 'DATE'
}

# Try connecting; if the configured URI has no inventory table, try common instance DB
def find_engine_with_inventory(engine):
    try:
        with engine.connect() as conn:
            res = conn.execute(text("SELECT name FROM sqlite_master WHERE type='table' AND name='inventory';")).fetchone()
            if res:
                return engine
    except Exception:
        pass
    # Try common fallback: instance/rentit.db relative to project root
    fallback_path = os.path.join(PROJECT_ROOT, 'instance', 'rentit.db')
    fallback_engine = try_connect_sqlite_path(fallback_path)
    if fallback_engine:
        try:
            with fallback_engine.connect() as conn:
                res = conn.execute(text("SELECT name FROM sqlite_master WHERE type='table' AND name='inventory';")).fetchone()
                if res:
                    print(f"Using fallback DB at {fallback_path}")
                    return fallback_engine
        except Exception:
            pass
    return None

engine_with_table = find_engine_with_inventory(engine)
if engine_with_table is None:
    print('Table `inventory` not found in database. Aborting.')
    sys.exit(1)

engine = engine_with_table

with engine.connect() as conn:
    # Get existing columns
    cols = [row[1] for row in conn.execute(text("PRAGMA table_info('inventory');")).fetchall()]
    to_add = []
    for col, coltype in required_columns.items():
        if col not in cols:
            to_add.append((col, coltype))

    if not to_add:
        print('No columns to add. Migration not needed.')
        sys.exit(0)

    print('Columns to add:', to_add)
    # Backup suggestion
    print('\nIMPORTANT: please make a backup of your database before proceeding.')

    # Support non-interactive confirmation via env var or --yes flag
    auto_confirm = os.getenv('MIGRATE_YES') == '1' or '--yes' in sys.argv
    if auto_confirm:
        # attempt to create a backup automatically
        try:
            # try to deduce sqlite file path from engine
            db_file = None
            try:
                db_file = engine.url.database
            except Exception:
                db_file = None
            if db_file and os.path.exists(db_file):
                backup_path = db_file + '.bak'
                if not os.path.exists(backup_path):
                    import shutil
                    shutil.copy2(db_file, backup_path)
                    print(f'Backup created: {backup_path}')
        except Exception as e:
            print('Warning: automatic backup failed:', e)
    else:
        confirm = input('Proceed with adding columns to the SQLite database? (yes/no): ')
        if confirm.lower() != 'yes':
            print('Aborted by user.')
            sys.exit(0)

    for col, coltype in to_add:
        alter_sql = f"ALTER TABLE inventory ADD COLUMN {col} {coltype};"
        print('Executing:', alter_sql)
        conn.execute(text(alter_sql))
    print('Columns added successfully. You may need to restart the app.')
