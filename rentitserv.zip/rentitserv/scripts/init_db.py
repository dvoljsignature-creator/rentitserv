#!/usr/bin/env python
"""
Database initialization script.
Creates all tables in the database.
"""
import sys
sys.path.insert(0, '/Users/Admin/Documents/rentit')

from app import create_app
from app.models import db

def init_db():
    """Initialize the database."""
    app = create_app()
    
    with app.app_context():
        print("Creating all tables...")
        db.create_all()
        print("Database initialized successfully!")

if __name__ == '__main__':
    init_db()
