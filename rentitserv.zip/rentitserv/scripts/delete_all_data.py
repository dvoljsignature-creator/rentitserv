import os
import shutil
import sys
from datetime import datetime

# Ensure local project package is imported instead of any globally installed `app` package.
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from typing import List

# Lazy placeholders (will be set in main())
create_app = None
db = None

DB_FILE = os.path.join(PROJECT_ROOT, 'rentit.db')


def is_production(app):
    env = os.getenv('FLASK_ENV', '').lower()
    if env == 'production':
        return True

    if app.config.get('SESSION_COOKIE_SECURE'):
        return True

    if not app.config.get('DEBUG', False) and not app.config.get('TESTING', False):
        return True

    return False


def backup_sqlite(db_path: str) -> str:
    if not os.path.exists(db_path):
        return ''

    ts = datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
    backup_path = f"{db_path}.backup.{ts}"
    try:
        shutil.copy2(db_path, backup_path)
        return backup_path
    except Exception:
        return ''


def prompt_confirm() -> bool:
    print('\nType the exact phrase "DELETE ALL DATA" to confirm and proceed.')
    confirm = input('> ').strip()
    if confirm != 'DELETE ALL DATA':
        print('Confirmation did not match. Aborting.')
        return False

    final = input('Final confirmation. Type YES to permanently delete all data: ').strip()
    if final != 'YES':
        print('Final confirmation failed. Aborting.')
        return False

    return True


def get_table_row_counts(tables) -> List[tuple]:
    import sqlalchemy as sa
    counts = []
    for t in tables:
        try:
            cnt = db.session.execute(sa.select(sa.func.count()).select_from(t)).scalar_one()
        except Exception:
            cnt = None
        counts.append((t.name, cnt))
    return counts


def main():
    print('Delete All Data (safe script)')
    print('This will permanently remove all rows from every table in the application DB.')
    print('Always backup your DB before running this script.')

    global create_app, db
    from app import create_app as _create_app
    from app.models import db as _db
    create_app = _create_app
    db = _db

    app = create_app()

    with app.app_context():
        if is_production(app) and os.getenv('FORCE_DELETE_ALL') != '1':
            print('\nRefusing to run in production-like environment.')
            print("If you really want to run this in production, set environment variable FORCE_DELETE_ALL=1 and re-run.")
            sys.exit(1)

        # Offer to back up sqlite DB if present
        if os.path.exists(DB_FILE):
            print(f"Detected sqlite DB at {DB_FILE}")
            backup = input('Create a backup copy before deleting? (Y/n): ').strip().lower() or 'y'
            if backup == 'y':
                backup_path = backup_sqlite(DB_FILE)
                if backup_path:
                    print(f'Backup created at: {backup_path}')
                else:
                    print('Backup failed or not possible; proceeding without file backup.')

        # Reflect metadata to ensure all tables are present
        try:
            db.metadata.reflect(bind=db.engine)
        except Exception as e:
            print('Could not reflect metadata:', str(e))

        tables = list(db.metadata.sorted_tables)
        if not tables:
            print('No tables detected in metadata. Exiting.')
            return

        # Show counts per table
        try:
            counts = get_table_row_counts(tables)
            print('\nRow counts by table:')
            for name, cnt in counts:
                print(f' - {name}: {cnt if cnt is not None else "?"}')
        except Exception:
            print('Could not fetch row counts; continuing.')

        if not prompt_confirm():
            return

        # For sqlite, temporarily disable foreign keys to allow deletion in any order
        is_sqlite = db.engine.name == 'sqlite'
        try:
            if is_sqlite:
                db.session.execute(db.text('PRAGMA foreign_keys=OFF'))

            # Delete rows from child tables first by reversing sorted_tables
            total_deleted = 0
            for t in reversed(tables):
                try:
                    res = db.session.execute(t.delete())
                    rc = getattr(res, 'rowcount', None)
                    if rc is None:
                        pass
                    else:
                        total_deleted += rc
                except Exception as e:
                    print(f'Error deleting from {t.name}: {e}')

            db.session.commit()

            if is_sqlite:
                db.session.execute(db.text('PRAGMA foreign_keys=ON'))

            print(f'Completed deletion. Approx. rows removed: {total_deleted}')

        except Exception as e:
            db.session.rollback()
            print('Error while deleting data:', str(e))
            sys.exit(1)


if __name__ == '__main__':
    main()
