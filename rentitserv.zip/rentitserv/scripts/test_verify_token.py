from app import create_app
from app.services.auth_service import AuthService
import jwt
from datetime import datetime, timedelta

app = create_app()

with app.app_context():
    secret = app.config['JWT_SECRET_KEY']

    print('\n--- Test 1: Malformed token ---')
    success, payload = AuthService.verify_token('not-a-jwt')
    print('Result:', success, payload)

    print('\n--- Test 2: Token with wrong signature ---')
    wrong_token = jwt.encode({'user_id': 1, 'exp': datetime.utcnow() + timedelta(minutes=5)}, 'wrong-secret', algorithm='HS256')
    success, payload = AuthService.verify_token(wrong_token)
    print('Result:', success, payload)

    print('\n--- Test 3: Expired token ---')
    expired_token = jwt.encode({'user_id': 1, 'exp': datetime.utcnow() - timedelta(minutes=5)}, secret, algorithm='HS256')
    success, payload = AuthService.verify_token(expired_token)
    print('Result:', success, payload)
