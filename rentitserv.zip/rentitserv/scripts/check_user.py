from app import create_app
from app.models import User

app = create_app()

with app.app_context():
    email = input('Email to check: ').strip()
    username = input('Username to check (optional): ').strip()

    if email:
        user = User.query.filter_by(email=email).first()
        if user:
            print(f'Found user with email {email}: id={user.id}, username={user.username}, created_at={user.created_at}')
        else:
            print(f'No user found with email {email}')

    if username:
        user = User.query.filter_by(username=username).first()
        if user:
            print(f'Found user with username {username}: id={user.id}, email={user.email}, created_at={user.created_at}')
        else:
            print(f'No user found with username {username}')
