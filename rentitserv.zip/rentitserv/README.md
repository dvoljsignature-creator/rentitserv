# RentIT

Небольшое README для проекта RentIT — бэкенд-приложения для аренды.

**Overview**
- **Project**: `RentIT` — Flask-приложение с пользовательской аутентификацией, TOTP, Google OAuth, отправкой писем и управлением ресурсами/инвентарём.
- **Repository layout**: основные папки — `app/` (код приложения), `scripts/` (утилиты и тестовые скрипты), `migrations/`, `tests/` (юнит- и интеграционные тесты), `instance/` (локальная БД), `static/` и `templates/`.

**Tech Stack**
- **Framework**: `Flask`.
- **DB**: `SQLAlchemy` (по умолчанию SQLite, переменная `DATABASE_URL` для смены).
- **Auth**: JWT, TOTP (двухфакторная аутентификация), Google OAuth.
- **Email**: SMTP (настраивается через переменные окружения).
- **Dev / Ops**: `Dockerfile`, `docker-compose.yml` (есть простая Docker-конфигурация).

**Important files**
- **`config.py`**: основные параметры и имена переменных окружения.
- **`run.py`**, **`manage.py`**: команды запуска и администрирования.
- **`requirements.txt`**: зависимости Python.
- **`scripts/`**: вспомогательные и тестовые скрипты (см. раздел «Скрипты и тесты»).

**Setup (локально)**
1. Установите зависимости:

```powershell
python -m pip install -r requirements.txt
```

2. Создайте виртуальное окружение (опционально) и установите переменные окружения (см. ниже).

3. Инициализация БД (если надо):

```powershell
python scripts\init_db.py
```

4. Запуск приложения локально:

```powershell
python run.py
```

или через Flask/Migrate/Manage команды (см. `manage.py`).

**Environment variables — токены и почта**
В `config.py` перечислены переменные окружения, которые вы можете задать в системе или в `.env` файле. Ниже — рекомендуемый набор и короткие пояснения.

- **`DATABASE_URL`**: строка подключения к БД (например, `sqlite:///rentit.db` или URL для Postgres).
- **`JWT_SECRET_KEY`**: секрет для подписания JWT; в продакшне обязателен постоянный безопасный ключ.
- **`MAIL_SERVER`**, **`MAIL_PORT`**, **`MAIL_USE_TLS`**: настройки SMTP-сервера (по умолчанию `smtp.gmail.com`, порт `587`).
- **`MAIL_USERNAME`**: логин почты (адрес отправителя).
- **`MAIL_PASSWORD`**: пароль/пароль приложения для SMTP — храните в безопасном месте (не в репозитории).
- **`MAIL_DEFAULT_SENDER`**: адрес отправителя по умолчанию.
- **`GOOGLE_CLIENT_ID`**, **`GOOGLE_CLIENT_SECRET`**: параметры Google OAuth (зарегистрируйте приложение в Google Cloud Console).
- **`GOOGLE_REDIRECT_URI`**: URL для обратного вызова OAuth (если не задан — собирается из `URL_SCHEME` и `SERVER_DOMAIN`).
- **`FRONTEND_URL`**: куда перенаправлять после успешного OAuth (по умолчанию `http://{SERVER_DOMAIN}`).
- **`SERVER_DOMAIN`**, **`URL_SCHEME`**, **`SERVER_PORT`** и пр. —используются для построения ссылок.

Пример `.env` (в корне проекта) или содержимого для локальной разработки:

```env
# server
URL_SCHEME=http
SERVER_DOMAIN=127.0.0.1:8192

# db
DATABASE_URL=sqlite:///rentit.db

# jwt
JWT_SECRET_KEY=your-very-secret-jwt-key

# mail
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=True
MAIL_USERNAME=youremail@gmail.com
MAIL_PASSWORD=your-smtp-password-or-app-password
MAIL_DEFAULT_SENDER=noreply@yourdomain.com

# google oauth
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret
# GOOGLE_REDIRECT_URI (опционально)

```

PowerShell пример установки переменных для текущего сеанса (Windows PowerShell):

```powershell
$env:JWT_SECRET_KEY = 'your-very-secret-jwt-key'
$env:MAIL_USERNAME = 'youremail@gmail.com'
$env:MAIL_PASSWORD = 'your-smtp-password-or-app-password'
python run.py
```

Советы по `MAIL_PASSWORD`:
- Для Gmail используйте пароль приложения (App Password) при двухфакторной аутентификации.
- Для других провайдеров используйте API-токен или SMTP-пароль, предоставляемый сервисом.

**Скрипты и тесты**
- **`scripts/init_db.py`**: скрипт инициализации базы данных.
- **`scripts/test_email_send.py`**, **`scripts/test_send_email.py`**, **`scripts/test_totp_email_echo.py`**: тестовые скрипты, связанные с отправкой писем и TOTP (проверяют работу email/TOTP логики).
- **`scripts/test_oauth.py`**, **`scripts/test_qr.py`**, **`scripts/test_verify_token.py`**: вспомогательные тесты авторизации и QR/TOTP.
- **`tests/`**: модульные тесты — запускаются через `pytest`.

Запуск тестов:

```powershell
pytest -q
```

Отдельные тестовые скрипты можно запускать прямо через Python, например:

```powershell
python scripts\test_send_email.py
```

**Docker**
- Есть `Dockerfile` и `docker-compose.yml`. Для локального теста через Docker:

```powershell
docker-compose up --build
```

При запуске в контейнере нужно передавать те же переменные окружения (через `docker-compose.yml` или `.env`).

**Полезные места в проекте**
- `app/services/` — логика отправки писем, TOTP и OAuth (`email_service.py`, `totp_service.py`, `oauth_service.py`, `password_reset_service.py`).
- `app/templates/` и `static/` — фронтенд-страницы для логина/регистрации/дэшборда и стили.

**Notes / Безопасность**
- Никогда не храните `MAIL_PASSWORD`, `JWT_SECRET_KEY`, `GOOGLE_CLIENT_SECRET` и другие секреты в публичных репозиториях.
- В продакшне используйте секретный менеджер (Vault, AWS Secrets Manager) или переменные окружения CI/CD.

---

Если хотите, могу:
- добавить пример `docker-compose.override.yml` с локальными переменными; 
- или сгенерировать `.env.example` в репозитории.

Если нужно — переведу README на английский или дополню конкретными командами для деплоя.
"""
RentIT Application - Flask Authentication API
===============================================

Modern Flask application with JWT authentication, two-factor authentication (TOTP),
Google OAuth integration, and password recovery.

Features:
- User registration and authentication
- Email-based and app-based TOTP (Google Authenticator)
- Google OAuth integration
- Password reset
- JWT tokens with refresh capability
- SQLAlchemy ORM with PostgreSQL/SQLite support
- Comprehensive error handling and logging

Installation
============

1. Install Python 3.8+
2. Create virtual environment:
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate

3. Install dependencies:
   pip install -r requirements.txt

4. Set environment variables (.env file):
   FLASK_ENV=development
   FLASK_DEBUG=True
   DATABASE_URL=sqlite:///rentit.db
   JWT_SECRET_KEY=your-secret-key
   MAIL_USERNAME=your-email@gmail.com
   MAIL_PASSWORD=your-app-password
   GOOGLE_CLIENT_ID=your-google-client-id
   GOOGLE_CLIENT_SECRET=your-google-client-secret

5. Run the application:
   python run.py

The app will be available at http://localhost:5000

Project Structure
=================

rentit/
├── app/
│   ├── models/          # SQLAlchemy database models
│   ├── services/        # Business logic (auth, TOTP, email, OAuth)
│   ├── views/           # API endpoints/blueprints
│   ├── templates/       # HTML templates
│   ├── static/          # CSS and JavaScript
│   └── __init__.py      # Flask app factory
├── tests/               # Unit tests
├── migrations/          # Database migrations
├── config.py           # Configuration management
├── logging_config.py   # Logging setup
├── requirements.txt    # Python dependencies
└── run.py             # Application entry point

API Endpoints
=============

Authentication
--------------

POST /api/auth/register
  Register a new user
  
  Request:
  {
    "email": "user@example.com",
    "username": "username",
    "password": "SecurePassword123!",
    "first_name": "John",
    "last_name": "Doe"
  }
  
  Response (201):
  {
    "message": "User registered successfully",
    "user": {
      "id": "uuid",
      "email": "user@example.com",
      "username": "username",
      "first_name": "John",
      "last_name": "Doe"
    }
  }

POST /api/auth/login
  Authenticate user
  
  Request:
  {
    "email": "user@example.com",
    "password": "SecurePassword123!"
  }
  
  Response (200):
  {
    "message": "Login successful",
    "tokens": {
      "access_token": "jwt_token",
      "refresh_token": "refresh_token",
      "token_type": "Bearer",
      "expires_in": 3600
    }
  }
  
  OR if TOTP is enabled (200):
  {
    "requires_totp": true,
    "user_id": "uuid",
    "message": "TOTP verification required"
  }

POST /api/auth/refresh
  Get new access token
  
  Request:
  {
    "refresh_token": "refresh_token_string"
  }
  
  Response (200):
  {
    "message": "Token refreshed successfully",
    "tokens": {
      "access_token": "new_jwt_token",
      "refresh_token": "refresh_token",
      "token_type": "Bearer",
      "expires_in": 3600
    }
  }

POST /api/auth/logout
  Revoke refresh token
  
  Headers:
  Authorization: Bearer access_token
  
  Request:
  {
    "refresh_token": "refresh_token_string"
  }
  
  Response (200):
  {
    "message": "Logged out successfully"
  }

GET /api/auth/profile
  Get current user profile
  
  Headers:
  Authorization: Bearer access_token
  
  Response (200):
  {
    "user": {
      "id": "uuid",
      "email": "user@example.com",
      "username": "username",
      "first_name": "John",
      "last_name": "Doe",
      "is_active": true,
      "is_verified": true,
      "totp_enabled": false,
      "totp_type": null,
      "created_at": "2024-01-01T00:00:00",
      "last_login": "2024-01-02T00:00:00"
    }
  }

Two-Factor Authentication (TOTP)
---------------------------------

POST /api/totp/setup/email
  Setup email-based TOTP
  
  Headers:
  Authorization: Bearer access_token
  
  Response (200):
  {
    "message": "TOTP code sent to your email",
    "code_sent": true
  }

POST /api/totp/verify/email
  Verify email TOTP code
  
  Headers:
  Authorization: Bearer access_token
  
  Request:
  {
    "code": "123456"
  }
  
  Response (200):
  {
    "message": "TOTP verified successfully",
    "tokens": { ... }
  }

POST /api/totp/setup/app
  Setup authenticator app TOTP
  
  Headers:
  Authorization: Bearer access_token
  
  Response (200):
  {
    "message": "Authenticator app setup",
    "setup_data": {
      "secret": "JBSWY3DPEBLW64TMMQ======",
      "qr_code": "data:image/png;base64,...",
      "backup_codes": ["CODE1", "CODE2", ...],
      "provisioning_uri": "otpauth://totp/..."
    }
  }

POST /api/totp/verify/app
  Verify app TOTP code
  
  Headers:
  Authorization: Bearer access_token
  
  Request:
  {
    "code": "123456"
  }
  
  Response (200):
  {
    "message": "TOTP verified successfully",
    "tokens": { ... }
  }

POST /api/totp/verify/login
  Verify TOTP during login
  
  Request:
  {
    "user_id": "uuid",
    "code": "123456"
  }
  
  Response (200):
  {
    "message": "Login successful",
    "tokens": { ... }
  }

POST /api/totp/disable
  Disable TOTP
  
  Headers:
  Authorization: Bearer access_token
  
  Response (200):
  {
    "message": "TOTP disabled successfully"
  }

Password Recovery
-----------------

POST /api/password/forgot
  Request password reset
  
  Request:
  {
    "email": "user@example.com"
  }
  
  Response (200):
  {
    "message": "If email exists, reset link will be sent"
  }

POST /api/password/reset
  Reset password with token
  
  Request:
  {
    "token": "reset_token_from_email",
    "new_password": "NewPassword123!"
  }
  
  Response (200):
  {
    "message": "Password reset successfully"
  }

Google OAuth
------------

GET /api/auth/google
  Redirect to Google OAuth authorization

GET /api/auth/google/callback
  Google OAuth callback (handled automatically)

Testing
=======

Run all tests:
  pytest

Run tests with coverage:
  pytest --cov=app tests/

Run specific test file:
  pytest tests/test_auth_service.py

Example cURL Commands
=====================

Register:
curl -X POST http://localhost:5000/api/auth/register \\
  -H "Content-Type: application/json" \\
  -d '{
    "email": "user@example.com",
    "username": "user",
    "password": "SecurePassword123!"
  }'

Login:
curl -X POST http://localhost:5000/api/auth/login \\
  -H "Content-Type: application/json" \\
  -d '{
    "email": "user@example.com",
    "password": "SecurePassword123!"
  }'

Get Profile:
curl -X GET http://localhost:5000/api/auth/profile \\
  -H "Authorization: Bearer ACCESS_TOKEN"

Password Reset Request:
curl -X POST http://localhost:5000/api/password/forgot \\
  -H "Content-Type: application/json" \\
  -d '{"email": "user@example.com"}'

Database
========

Supported databases:
- SQLite (default, development)
- PostgreSQL (production)

Create tables:
- Automatic on app startup

Models:
- User: User accounts with email, username, password hash
- TOTPSettings: Two-factor authentication settings
- RefreshToken: JWT refresh tokens with revocation

Security Features
=================

- Password hashing with Werkzeug
- JWT tokens with expiration
- Refresh token rotation
- TOTP support (email and authenticator app)
- Password reset with secure tokens
- Email verification
- Google OAuth integration
- CORS protection
- SQL injection prevention (SQLAlchemy ORM)
- CSRF protection available

Architecture
============

Models (app/models/)
- Database models with SQLAlchemy
- Foreign key relationships
- Timestamps and soft deletes

Services (app/services/)
- AuthService: User authentication and token management
- TOTPService: Two-factor authentication
- EmailService: Email notifications
- GoogleOAuthService: OAuth integration
- PasswordResetService: Password recovery

Views (app/views/)
- RESTful API endpoints
- Error handling
- Request validation

Utilities (app/utils/)
- Helper functions
- Validators
- Decorators

Configuration
=============

Environment-specific configs:
- Development: Debug=True, SQLite database
- Production: Debug=False, PostgreSQL database
- Testing: In-memory database, mock services

See config.py for all configuration options

Logging
=======

Application logs are stored in:
- logs/rentit.log
- Console output (development)

Log levels:
- DEBUG: Detailed information
- INFO: General information
- WARNING: Warning messages
- ERROR: Error messages

Deployment
==========

Production setup:
1. Use PostgreSQL instead of SQLite
2. Set FLASK_ENV=production
3. Use strong JWT_SECRET_KEY
4. Configure email SMTP settings
5. Set up HTTPS/SSL
6. Use production WSGI server (Gunicorn, uWSGI)
7. Configure reverse proxy (Nginx)

Example Gunicorn command:
gunicorn -w 4 -b 0.0.0.0:5000 run:app

Contributing
============

1. Create feature branch
2. Follow PEP8 style guide
3. Add tests for new features
4. Update documentation
5. Submit pull request

License
=======

MIT License - See LICENSE file for details

Support
=======

For issues and feature requests, please use the issue tracker.
"""
